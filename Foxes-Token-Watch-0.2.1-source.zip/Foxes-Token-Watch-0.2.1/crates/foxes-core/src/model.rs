//! 各家 agent 共用的数据模型。

use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Agent {
    Claude,
    Codex,
    Deepseek,
    Antigravity,
    Kiro,
    Cursor,
    /// 保留旧快照与本机记录的分类标识；Cursor 内的 MCP 对话现在统一归入 Cursor。
    #[serde(rename = "webmcp")]
    WebMcp,
}

impl Agent {
    pub const COUNT: usize = 7;
    pub const ALL: [Agent; Agent::COUNT] =
        [Agent::Claude, Agent::Codex, Agent::Deepseek, Agent::Antigravity, Agent::Kiro, Agent::Cursor, Agent::WebMcp];

    pub fn index(self) -> usize {
        self as usize
    }

    pub fn id(self) -> &'static str {
        match self {
            Agent::Claude => "claude",
            Agent::Codex => "codex",
            Agent::Deepseek => "deepseek",
            Agent::Antigravity => "antigravity",
            Agent::Kiro => "kiro",
            Agent::Cursor => "cursor",
            Agent::WebMcp => "webmcp",
        }
    }

    pub fn from_id(id: &str) -> Option<Agent> {
        Agent::ALL.into_iter().find(|agent| agent.id() == id)
    }

    pub fn label(self) -> &'static str {
        match self {
            Agent::Claude => "Claude Code",
            Agent::Codex => "Codex",
            Agent::Deepseek => "Deepseek Harness",
            Agent::Antigravity => "Antigravity",
            Agent::Kiro => "Kiro",
            Agent::Cursor => "Cursor",
            Agent::WebMcp => "网页 MCP",
        }
    }

    /// 来源本身不记录 token 用量，数字由本程序估算。
    pub fn estimates_tokens(self) -> bool {
        matches!(self, Agent::Kiro | Agent::Cursor | Agent::WebMcp)
    }
}

/// 统一口径的 token 用量。
///
/// `input` 只算未命中缓存的输入；`reasoning` 是 `output` 的子集，不重复计入总量。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Usage {
    pub input: u64,
    pub cache_read: u64,
    pub cache_write: u64,
    pub output: u64,
    pub reasoning: u64,
}

impl Usage {
    pub fn total(&self) -> u64 {
        self.input + self.cache_read + self.cache_write + self.output
    }

    pub fn prompt(&self) -> u64 {
        self.input + self.cache_read + self.cache_write
    }

    pub fn is_zero(&self) -> bool {
        self.total() == 0
    }

    pub fn add(&mut self, other: &Usage) {
        self.input += other.input;
        self.cache_read += other.cache_read;
        self.cache_write += other.cache_write;
        self.output += other.output;
        self.reasoning += other.reasoning;
    }
}

/// 一次模型响应。
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct UsageEvent {
    /// 响应结束时刻（epoch 毫秒）
    pub ts: i64,
    pub usage: Usage,
    /// 所属文件 `models` 表里的下标
    pub model: u16,
    /// 跨文件去重键，0 表示不参与去重
    pub key: u64,
    /// 请求发出到响应结束的耗时，0 表示未知
    pub latency_ms: u32,
    /// 首字（首个内容块）延迟，0 表示未知
    pub ttft_ms: u32,
    /// 思考时长，0 表示未知
    pub think_ms: u32,
    /// 思考 token 是按文本占比估算的（来源没有记录精确值）
    pub reasoning_estimated: bool,
    /// 整条用量都是估算的：来源没有记录 token，按上下文读数和文本体量推算
    pub estimated: bool,
    /// 这次计费消耗的额度（Kiro 的 credits），0 表示来源没有记录
    pub credits: f32,
}

/// 会话当前在做什么。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Phase {
    #[default]
    Idle,
    /// 请求已发出，还没有任何输出（排队 / 等待响应）
    Requesting,
    Thinking,
    Writing,
    /// 来源分不出思考和写入时统称“生成中”
    Generating,
    Tool,
    Retrying,
    /// 等待用户确认
    Waiting,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum NetKind {
    Retry,
    Error,
}

/// 一次网络 / 接口异常（只保留错误码，不保留报错正文）。
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NetEvent {
    pub ts: i64,
    pub kind: NetKind,
    pub code: String,
    pub attempt: u32,
    pub max_attempts: u32,
    pub delay_ms: u32,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SessionMeta {
    pub id: String,
    pub title: String,
    pub cwd: String,
    pub started_ms: i64,
    pub last_active_ms: i64,
    /// 最近一次请求占用的上下文（token）
    pub context_used: u64,
    pub context_window: u64,
    /// 子代理会话：用量照常统计，但不单独计入“对话数”
    pub sub_agent: bool,
    pub parent_id: String,
    pub app_version: String,
}

/// 从记录末尾推断出的实时状态。
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LiveTrack {
    pub turn_open: bool,
    pub turn_started_ms: i64,
    pub phase: Phase,
    pub phase_since_ms: i64,
    pub tool: String,
    pub turns: u32,
    pub last_turn_ms: u64,
    pub last_turn_end_ms: i64,
}

impl LiveTrack {
    pub fn set_phase(&mut self, phase: Phase, ts: i64) {
        if self.phase != phase {
            self.phase = phase;
            self.phase_since_ms = ts;
        }
        if phase != Phase::Tool {
            self.tool.clear();
        }
    }

    pub fn open_turn(&mut self, ts: i64) {
        if !self.turn_open {
            self.turn_open = true;
            self.turn_started_ms = ts;
        }
    }

    pub fn close_turn(&mut self, ts: i64, duration_ms: Option<u64>) {
        if self.turn_open {
            self.turns += 1;
            self.last_turn_ms = duration_ms.unwrap_or_else(|| (ts - self.turn_started_ms).max(0) as u64);
            self.last_turn_end_ms = ts;
        }
        self.turn_open = false;
        self.set_phase(Phase::Idle, ts);
    }
}

#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct RateWindow {
    pub used_percent: f64,
    pub window_minutes: u64,
    /// 额度重置时刻（epoch 毫秒），0 表示未知
    pub resets_at_ms: i64,
    /// 已用量和上限（按 `unit` 计），上限为 0 表示来源只给了百分比
    pub used: f64,
    pub limit: f64,
    /// 计量单位，比如 `credits`；空表示未知
    pub unit: String,
    /// 额度名称，比如“每月额度”；空时界面按时间窗口命名
    pub label: String,
    /// `resets_at_ms` 是到期时刻（赠送额度到期作废），不是重置时刻
    pub expires: bool,
}

/// 额度使用情况（Codex 的时间窗口额度、Kiro 的每月 credits）。
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RateLimits {
    pub ts: i64,
    pub primary: Option<RateWindow>,
    pub secondary: Option<RateWindow>,
    pub plan: String,
}

/// 一次工具调用（详情页的工具统计用）。只保留工具名和结果，不保留参数。
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct ToolCall {
    pub ts: i64,
    pub name: String,
    /// MCP 服务名；内置工具为空
    pub server: String,
    pub ok: bool,
}
