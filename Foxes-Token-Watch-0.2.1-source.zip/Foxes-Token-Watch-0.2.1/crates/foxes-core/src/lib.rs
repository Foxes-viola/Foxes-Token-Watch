//! Foxes Token Watch 内核：读取本机各 AI agent 的会话记录，统计 token 用量与实时状态。
//!
//! 只读、不联网；只取用量数字、时间和状态，不保留对话正文。

pub mod aggregate;
pub mod estimate;
pub mod journal;
pub mod lenient;
pub mod live;
pub mod model;
pub mod proto;
pub mod sources;
pub mod store;
pub mod timeutil;
pub mod zstdframes;

pub use aggregate::{analyze, Analysis, SessionView, Snapshot};
pub use model::{Agent, Phase, Usage};
pub use sources::Roots;
pub use store::Store;
