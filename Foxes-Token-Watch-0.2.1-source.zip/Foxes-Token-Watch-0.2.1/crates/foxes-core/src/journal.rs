//! Replace the observed session snapshot on updates; keep the last observation
//! if the source disappears. Never persist prompts, tool arguments or responses.
use crate::model::Agent;
use crate::sources::{FileSig, ParserState};
use crate::store::Store;
use rusqlite::{params, Connection};
use serde_json::json;
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};

pub struct Journal {
    db: Connection,
    saved: HashMap<PathBuf, FileSig>,
}
impl Journal {
    pub fn open(path: &Path) -> rusqlite::Result<Self> {
        let db = Connection::open(path)?;
        db.execute_batch("CREATE TABLE IF NOT EXISTS sessions (
            source TEXT NOT NULL, session TEXT NOT NULL, agent TEXT NOT NULL, updated_ms INTEGER NOT NULL,
            total_tokens INTEGER NOT NULL, estimated_tokens INTEGER NOT NULL, credits REAL NOT NULL,
            usage_json TEXT NOT NULL, tools_json TEXT NOT NULL, PRIMARY KEY(source, session, agent))")?;
        Ok(Self {
            db,
            saved: HashMap::new(),
        })
    }
    pub fn sync(&mut self, store: &Store) -> rusqlite::Result<()> {
        for file in store.source_files().filter(|f| f.agent.estimates_tokens()) {
            let stamp = match &file.parser {
                ParserState::Cursor(state) => FileSig {
                    mtime_ms: state.revision,
                    ..FileSig::default()
                },
                _ => file.sig,
            };
            if file.gone
                || file.errors != 0
                || file.corrupt
                || self.saved.get(&file.path) == Some(&stamp)
            {
                continue;
            }
            let source = file.path.to_string_lossy();
            let tx = self.db.transaction()?;
            let parts = Some(file)
                .filter(|f| f.agent != Agent::Cursor)
                .into_iter()
                .chain(file.extra.iter());
            for part in parts {
                let mut total = 0;
                let mut estimated = 0;
                let mut credits = 0.0;
                let mut usage = Vec::with_capacity(part.events.len());
                for event in &part.events {
                    total += event.usage.total();
                    if event.estimated {
                        estimated += event.usage.total();
                    }
                    credits += f64::from(event.credits);
                    usage.push(json!({"ts":event.ts,"model":part.model_name(event.model),"tokens":event.usage,
                        "total":event.usage.total(),"estimated":event.estimated,"credits":event.credits}));
                }
                // 网关卡片和它对应的 Cursor 对话共用会话 id，按各自的来源文件分开记
                let part_source = part.path.to_string_lossy();
                tx.execute("INSERT INTO sessions VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9)
                    ON CONFLICT(source,session,agent) DO UPDATE SET updated_ms=excluded.updated_ms,
                    total_tokens=excluded.total_tokens, estimated_tokens=excluded.estimated_tokens,
                    credits=excluded.credits,usage_json=excluded.usage_json,tools_json=excluded.tools_json
                    WHERE sessions.usage_json!=excluded.usage_json OR sessions.tools_json!=excluded.tools_json
                    OR sessions.updated_ms!=excluded.updated_ms",
                    params![part_source.as_ref(),part.session.id,part.agent.id(),part.session.last_active_ms,total,estimated,credits,
                        serde_json::to_string(&usage).unwrap(),serde_json::to_string(&part.tools).unwrap()])?;
            }
            if file.agent == Agent::Cursor {
                let routes: HashSet<_> = file
                    .extra
                    .iter()
                    .map(|p| (&p.session.id, p.agent))
                    .collect();
                for (id, agent) in &routes {
                    let other = if *agent == Agent::Cursor {
                        Agent::WebMcp
                    } else {
                        Agent::Cursor
                    };
                    if !routes.contains(&(*id, other)) {
                        tx.execute(
                            "DELETE FROM sessions WHERE source=?1 AND session=?2 AND agent=?3",
                            params![source.as_ref(), id, other.id()],
                        )?;
                    }
                }
            }
            tx.commit()?;
            self.saved.insert(file.path.clone(), stamp);
        }
        Ok(())
    }
}
