"""Collect license notices from cached Rust crates and installed frontend dependencies."""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def license_files(package):
    return sorted(
        p for p in package.rglob("*")
        if p.is_file() and p.name.upper().startswith(("LICENSE", "LICENCE", "COPYING", "COPYRIGHT", "NOTICE"))
        and p.suffix.lower() not in {".rs", ".js", ".ts", ".json", ".png", ".svg"}
    )


def main():
    result = subprocess.run(
        ["cargo", "metadata", "--offline", "--locked", "--filter-platform", "x86_64-pc-windows-msvc", "--format-version", "1"],
        cwd=ROOT, capture_output=True, encoding="utf-8", check=True,
    )
    metadata = json.loads(result.stdout)
    packages = {p["id"]: p for p in metadata["packages"]}
    nodes = {n["id"]: n for n in metadata["resolve"]["nodes"]}
    queue = [p["id"] for p in metadata["packages"] if p["name"] == "foxes-token-watch"]
    runtime = set()
    while queue:
        key = queue.pop()
        if key in runtime or any("proc-macro" in target["kind"] for target in packages[key]["targets"]):
            continue
        runtime.add(key)
        queue.extend(dep["pkg"] for dep in nodes[key]["deps"] if any(kind["kind"] is None for kind in dep["dep_kinds"]))
    fallbacks = {
        ("alloc-stdlib", "0.3.0"): "alloc-stdlib-0.3.0-LICENSE.txt",
        ("selectors", "0.38.0"): "MPL-2.0.txt",
        ("webview2-com", "0.39.1"): "webview2-rs-LICENSE.txt",
        ("webview2-com-sys", "0.39.1"): "webview2-rs-LICENSE.txt",
    }
    entries = []
    missing = []
    for key in runtime:
        package = packages[key]
        if not (package.get("source") or "").startswith("registry+"):
            continue
        name, version = package["name"], package["version"]
        folder = Path(package["manifest_path"]).parent
        files = license_files(folder)
        if not files and (name, version) in fallbacks:
            folder = ROOT / "docs" / "licenses"
            files = [folder / fallbacks[(name, version)]]
        if not files:
            missing.append(f"cargo:{name}@{version}")
            continue
        entries.append((f"Rust: {name} {version}", package.get("license", "See license text"), folder, files, f"https://crates.io/crates/{name}/{version}"))

    queue = list(json.loads((ROOT / "package.json").read_text(encoding="utf-8"))["dependencies"])
    seen = set()
    while queue:
        name = queue.pop()
        if name in seen:
            continue
        seen.add(name)
        folder = ROOT / "node_modules" / name
        metadata = json.loads((folder / "package.json").read_text(encoding="utf-8"))
        files = license_files(folder)
        if not files:
            missing.append(f"npm:{name}@{metadata['version']}")
            continue
        entries.append((f"JavaScript: {name} {metadata['version']}", metadata.get("license", "See license text"), folder, files, f"https://www.npmjs.com/package/{name}/v/{metadata['version']}"))
        queue.extend(metadata.get("dependencies", {}))

    if missing:
        raise SystemExit("Missing license texts or cached crate sources: " + ", ".join(missing))
    parts = [
        "Foxes Token Watch - Third-party notices\n",
        "The licenses below apply to third-party components, independently of the project's PolyForm Noncommercial license.\n",
        "Rust notices cover normal dependencies resolved for the Windows x64 application, excluding build dependencies and procedural-macro tools. JavaScript notices cover runtime dependencies. Source code can be obtained through each component's package page below.\n",
    ]
    texts = {}
    for title, identifier, folder, files, source in sorted(entries, key=lambda entry: entry[0]):
        parts.append(f"\n{'=' * 72}\n{title}\nLicense: {identifier}\nSource: {source}\n")
        for file in files:
            parts.append(f"\n--- {file.relative_to(folder).as_posix()} ---\n")
            text = file.read_text(encoding="utf-8", errors="replace").strip()
            index = texts.setdefault(text, len(texts) + 1)
            parts.append(f"See license text #{index} below.\n")
    for text, index in texts.items():
        parts.append(f"\n{'=' * 72}\nLicense text #{index}\n\n{text}\n")
    output = ROOT / "THIRD_PARTY_NOTICES.txt"
    output.write_text("\n".join(parts), encoding="utf-8")
    print(json.dumps({"components": len(entries), "bytes": output.stat().st_size}))


if __name__ == "__main__":
    main()
