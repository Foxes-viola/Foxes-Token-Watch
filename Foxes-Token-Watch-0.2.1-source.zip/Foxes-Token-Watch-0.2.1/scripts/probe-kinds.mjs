#!/usr/bin/env node
// 跨文件统计事件种类与顺序（只输出枚举值和计数，不输出对话内容）。
//   node scripts/probe-kinds.mjs codex-seq <rollout.jsonl>
//   node scripts/probe-kinds.mjs codex-types <sessions 目录> [文件数]
//   node scripts/probe-kinds.mjs claude-types <projects 目录> [文件数]
import fs from 'node:fs'
import path from 'node:path'

function walk(dir, ext, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) walk(full, ext, out)
    else if (entry.name.endsWith(ext)) out.push(full)
  }
  return out
}

function newest(dir, ext, count) {
  return walk(dir, ext)
    .map((file) => ({ file, mtime: fs.statSync(file).mtimeMs }))
    .sort((a, b) => b.mtime - a.mtime)
    .slice(0, count)
    .map((item) => item.file)
}

function* lines(file) {
  const text = fs.readFileSync(file, 'utf8')
  let start = 0
  while (start < text.length) {
    let end = text.indexOf('\n', start)
    if (end === -1) end = text.length
    const line = text.slice(start, end)
    start = end + 1
    if (!line.trim()) continue
    try {
      yield JSON.parse(line)
    } catch {
      // 末行可能正在写入
    }
  }
}

function bump(map, key) {
  map[key] = (map[key] ?? 0) + 1
}

function sorted(map) {
  return Object.entries(map)
    .sort((a, b) => b[1] - a[1])
    .map(([key, value]) => `${key}=${value}`)
    .join('  ')
}

const [mode, target, countArg] = process.argv.slice(2)
const count = Number(countArg ?? 40)

if (mode === 'codex-seq') {
  let shown = 0
  for (const line of lines(target)) {
    const kind = line.type === 'event_msg' ? line.payload?.type : line.type
    if (!['token_count', 'token_usage_record', 'task_started', 'task_complete', 'turn_aborted', 'turn_context'].includes(kind)) continue
    let detail = ''
    if (kind === 'token_count') detail = `total=${line.payload.info?.total_token_usage?.total_tokens ?? 'null'} last=${line.payload.info?.last_token_usage?.total_tokens ?? 'null'}`
    if (kind === 'token_usage_record') detail = `usage=${line.payload.usage?.total_tokens} turn=${line.payload.turn_token_usage?.total_tokens} thread=${line.payload.thread_token_usage?.total_tokens} keys=${Object.keys(line.payload).join(',')}`
    if (kind === 'task_complete') detail = `duration_ms=${line.payload.duration_ms} ttft=${line.payload.time_to_first_token_ms}`
    console.log(line.ordinal, kind, detail)
    shown += 1
    if (shown >= 26) break
  }
} else if (mode === 'codex-types') {
  const kinds = {}
  const sources = {}
  const versions = {}
  const originators = {}
  let forked = 0
  let withRecords = 0
  let withCounts = 0
  const files = newest(target, '.jsonl', count)
  for (const file of files) {
    let hasRecord = false
    let hasCount = false
    for (const line of lines(file)) {
      const kind = line.payload?.type ? `${line.type}/${line.payload.type}` : line.type
      bump(kinds, kind)
      if (line.type === 'session_meta') {
        const source = line.payload.source
        bump(sources, typeof source === 'object' && source ? `{${Object.keys(source).join(',')}${source.subagent && typeof source.subagent === 'object' ? ':' + Object.keys(source.subagent).join(',') : ''}}` : String(source))
        bump(versions, line.payload.cli_version)
        bump(originators, line.payload.originator)
        if (line.payload.forked_from_id) forked += 1
      }
      if (line.type === 'token_usage_record') hasRecord = true
      if (line.payload?.type === 'token_count') hasCount = true
    }
    if (hasRecord) withRecords += 1
    if (hasCount) withCounts += 1
  }
  console.log('files:', files.length, 'with token_usage_record:', withRecords, 'with token_count:', withCounts, 'forked:', forked)
  console.log('kinds:', sorted(kinds))
  console.log('sources:', sorted(sources))
  console.log('versions:', sorted(versions))
  console.log('originators:', sorted(originators))
} else if (mode === 'claude-types') {
  const kinds = {}
  const stops = {}
  const blocks = {}
  const entrypoints = {}
  const versions = {}
  let sidechainLines = 0
  let thinkingNonZero = 0
  let usageLines = 0
  const idFiles = new Map()
  const files = newest(target, '.jsonl', count)
  const subagentFiles = walk(target, '.jsonl').filter((file) => /subagents|agent-/.test(path.basename(path.dirname(file)) + '/' + path.basename(file))).length
  for (const file of files) {
    for (const line of lines(file)) {
      bump(kinds, line.subtype ? `${line.type}/${line.subtype}` : line.type)
      if (line.isSidechain) sidechainLines += 1
      if (line.entrypoint) bump(entrypoints, line.entrypoint)
      if (line.version) bump(versions, line.version)
      if (line.type === 'assistant' && line.message) {
        bump(stops, String(line.message.stop_reason))
        for (const block of line.message.content ?? []) bump(blocks, block.type)
        if (line.message.usage) {
          usageLines += 1
          if ((line.message.usage.output_tokens_details?.thinking_tokens ?? 0) > 0) thinkingNonZero += 1
        }
        if (line.message.id) {
          const set = idFiles.get(line.message.id) ?? new Set()
          set.add(file)
          idFiles.set(line.message.id, set)
        }
      }
    }
  }
  let crossFile = 0
  for (const set of idFiles.values()) if (set.size > 1) crossFile += 1
  console.log('files:', files.length, 'subagent-like files (all):', subagentFiles)
  console.log('kinds:', sorted(kinds))
  console.log('stop_reason:', sorted(stops))
  console.log('blocks:', sorted(blocks))
  console.log('entrypoints:', sorted(entrypoints))
  console.log('versions:', sorted(versions))
  console.log('sidechain lines:', sidechainLines, 'usage lines:', usageLines, 'thinking_tokens>0 lines:', thinkingNonZero)
  console.log('unique message ids:', idFiles.size, 'ids appearing in >1 file:', crossFile)
} else {
  console.error('usage: probe-kinds.mjs <codex-seq|codex-types|claude-types> <path> [count]')
  process.exit(1)
}
