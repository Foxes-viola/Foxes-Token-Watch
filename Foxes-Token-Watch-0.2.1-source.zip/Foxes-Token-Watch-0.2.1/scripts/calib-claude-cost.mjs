// 拿 Claude Code 自己记的 cost-state（按模型累计的 outputTokens / thinkingTokens）和逐条消息的数字对照。
// 只输出数字。用法：node scripts/calib-claude-cost.mjs <projects 目录>
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';

const root = process.argv[2];

function* walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(full);
    else if (entry.name.endsWith('.jsonl')) yield full;
  }
}

function weight(text) {
  let ascii = 0;
  let wide = 0;
  for (const ch of text ?? '') {
    if (ch.codePointAt(0) < 128) ascii += 1;
    else wide += 1;
  }
  return ascii + 5 * wide;
}

let index = 0;
const totals = { costOut: 0, costThink: 0, msgOut: 0, share: 0, exact: 0 };
for (const file of walk(root)) {
  const reader = readline.createInterface({ input: fs.createReadStream(file), crlfDelay: Infinity });
  const messages = new Map();
  const states = [];
  let lineNo = 0;
  for await (const line of reader) {
    lineNo += 1;
    if (!line) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch {
      continue;
    }
    if (row.type === 'cost-state') {
      states.push({ lineNo, usage: row.modelUsage ?? {}, api: row.totalAPIDuration, cost: row.totalCostUSD });
      continue;
    }
    if (row.type !== 'assistant' || !row.message?.id) continue;
    let item = messages.get(row.message.id);
    if (!item) {
      item = { model: String(row.message.model), output: 0, exact: 0, think: 0, visible: 0, lineNo, sidechain: !!row.isSidechain };
      messages.set(row.message.id, item);
    }
    const usage = row.message.usage ?? {};
    item.output = Math.max(item.output, usage.output_tokens ?? 0);
    item.exact = Math.max(item.exact, usage.output_tokens_details?.thinking_tokens ?? 0);
    for (const block of Array.isArray(row.message.content) ? row.message.content : []) {
      if (block.type === 'thinking') item.think += weight(block.thinking);
      else if (block.type === 'text') item.visible += weight(block.text);
      else if (block.type === 'tool_use') item.visible += weight(JSON.stringify(block.input ?? {})) + weight(block.name);
    }
  }
  if (!states.length) continue;
  index += 1;
  const last = states[states.length - 1];
  const list = [...messages.values()];
  console.log(`file #${index}: cost-state lines ${states.length} (at line ${states.map((state) => state.lineNo).join(',')} of ${lineNo}), messages ${list.length}, sidechain ${list.filter((item) => item.sidechain).length}`);
  for (const [model, usage] of Object.entries(last.usage)) {
    const mine = list.filter((item) => item.model === model && item.lineNo <= last.lineNo);
    const after = list.filter((item) => item.model === model && item.lineNo > last.lineNo).length;
    const msgOut = mine.reduce((sum, item) => sum + item.output, 0);
    const exact = mine.reduce((sum, item) => sum + item.exact, 0);
    const share = mine.reduce((sum, item) => sum + (item.exact > 0 ? item.exact : item.think + item.visible > 0 ? (item.output * item.think) / (item.think + item.visible) : 0), 0);
    const safeModel = /^[A-Za-z0-9_.:-]{1,40}$/.test(model) ? model : '<model>';
    console.log(
      `   ${safeModel}: cost-state out=${usage.outputTokens} thinking=${usage.thinkingTokens} (${((usage.thinkingTokens / Math.max(1, usage.outputTokens)) * 100).toFixed(0)}%)` +
        ` | messages before it: n=${mine.length} out=${msgOut} exact=${exact} share-estimate=${Math.round(share)} (${((share / Math.max(1, msgOut)) * 100).toFixed(0)}%) | messages after: ${after}`,
    );
    totals.costOut += usage.outputTokens ?? 0;
    totals.costThink += usage.thinkingTokens ?? 0;
    totals.msgOut += msgOut;
    totals.share += share;
    totals.exact += exact;
  }
}
console.log(`TOTAL cost-state out=${totals.costOut} thinking=${totals.costThink} | messages out=${totals.msgOut} exact=${totals.exact} share-estimate=${Math.round(totals.share)}`);
