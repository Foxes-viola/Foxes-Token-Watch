#!/usr/bin/env node
// 用量字段的算式核对（只输出数字和字段名，不输出任何对话内容）。
//   node scripts/probe-usage.mjs codex <rollout.jsonl>
//   node scripts/probe-usage.mjs dsh <session.v4.jsonl.zstd>
//   node scripts/probe-usage.mjs claude <session.jsonl>
import fs from 'node:fs'
import zlib from 'node:zlib'

function splitZstdFrames(buf) {
  const frames = []
  let pos = 0
  while (pos + 4 <= buf.length) {
    const start = pos
    const magic = buf.readUInt32LE(pos)
    if ((magic & 0xfffffff0) === 0x184d2a50) {
      pos += 8 + buf.readUInt32LE(pos + 4)
      continue
    }
    if (magic !== 0xfd2fb528) throw new Error(`not a zstd frame at offset ${pos}`)
    const descriptor = buf[pos + 4]
    const fcsFlag = descriptor >> 6
    const singleSegment = (descriptor >> 5) & 1
    const hasChecksum = (descriptor >> 2) & 1
    const dictIdSize = [0, 1, 2, 4][descriptor & 3]
    const fcsSize = fcsFlag === 0 ? singleSegment : [0, 2, 4, 8][fcsFlag]
    pos += 5 + (singleSegment ? 0 : 1) + dictIdSize + fcsSize
    for (;;) {
      const header = buf[pos] | (buf[pos + 1] << 8) | (buf[pos + 2] << 16)
      const last = header & 1
      const type = (header >> 1) & 3
      const size = header >> 3
      pos += 3 + (type === 1 ? 1 : size)
      if (last) break
    }
    if (hasChecksum) pos += 4
    frames.push(buf.subarray(start, pos))
  }
  return frames
}

function readLines(file) {
  const buf = fs.readFileSync(file)
  const text = file.endsWith('.zstd')
    ? splitZstdFrames(buf).map((frame) => zlib.zstdDecompressSync(frame).toString('utf8')).join('')
    : buf.toString('utf8')
  const out = []
  for (const line of text.split('\n')) {
    if (!line.trim()) continue
    try {
      out.push(JSON.parse(line))
    } catch {
      // 末行可能正在写入
    }
  }
  return out
}

// 只展示键名和数字；字符串只给长度
function shape(value, depth = 0) {
  if (value === null) return 'null'
  if (Array.isArray(value)) return depth > 4 ? '[…]' : `[${value.slice(0, 2).map((v) => shape(v, depth + 1)).join(', ')}${value.length > 2 ? `, …x${value.length}` : ''}]`
  if (typeof value === 'object') {
    if (depth > 4) return '{…}'
    return `{ ${Object.entries(value).map(([k, v]) => `${k}: ${shape(v, depth + 1)}`).join(', ')} }`
  }
  if (typeof value === 'string') return `str(${value.length})`
  return String(value)
}

const [mode, file] = process.argv.slice(2)
const lines = readLines(file)

if (mode === 'codex') {
  const record = lines.find((line) => line.type === 'token_usage_record')
  console.log('token_usage_record:', record ? shape(record) : '(none)')
  let prevTotal = null
  let sumLast = { input: 0, cached: 0, cacheWrite: 0, output: 0, reasoning: 0, total: 0 }
  let count = 0
  let dupes = 0
  let lastTotalUsage = null
  for (const line of lines) {
    if (line.type !== 'event_msg' || line.payload?.type !== 'token_count') continue
    const info = line.payload.info
    if (!info) continue
    const total = info.total_token_usage
    const last = info.last_token_usage
    if (prevTotal !== null && total.total_tokens === prevTotal) {
      dupes += 1 // 同一累计值重复上报（只刷新限额），不能重复计入
      continue
    }
    prevTotal = total.total_tokens
    lastTotalUsage = total
    count += 1
    sumLast.input += last.input_tokens
    sumLast.cached += last.cached_input_tokens ?? 0
    sumLast.cacheWrite += last.cache_write_input_tokens ?? 0
    sumLast.output += last.output_tokens
    sumLast.reasoning += last.reasoning_output_tokens ?? 0
    sumLast.total += last.total_tokens
  }
  console.log('token_count events:', count, 'duplicates skipped:', dupes)
  console.log('sum(last_token_usage):', JSON.stringify(sumLast))
  console.log('final total_token_usage:', JSON.stringify(lastTotalUsage))
  if (lastTotalUsage) {
    console.log('total == input + output ?', lastTotalUsage.total_tokens === lastTotalUsage.input_tokens + lastTotalUsage.output_tokens)
  }
} else if (mode === 'dsh') {
  let ok = 0
  let bad = 0
  const sum = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 }
  const examples = []
  for (const line of lines) {
    if (line.type !== 'assistant/message') continue
    const usage = line.data?.usage
    if (!usage) continue
    const computed = (usage.inputTokens ?? 0) + (usage.outputTokens ?? 0) + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0)
    if (computed === usage.totalTokens) ok += 1
    else {
      bad += 1
      if (examples.length < 3) examples.push(JSON.stringify(usage))
    }
    sum.input += usage.inputTokens ?? 0
    sum.output += usage.outputTokens ?? 0
    sum.cacheRead += usage.cacheReadTokens ?? 0
    sum.cacheWrite += usage.cacheWriteTokens ?? 0
    sum.total += usage.totalTokens ?? 0
  }
  console.log('assistant/message with usage: total==in+out+cacheRead+cacheWrite ok:', ok, 'mismatch:', bad)
  for (const example of examples) console.log('  mismatch example:', example)
  console.log('sum:', JSON.stringify(sum))
  const types = {}
  for (const line of lines) types[line.type] = (types[line.type] ?? 0) + 1
  console.log('event types:', JSON.stringify(types))
} else if (mode === 'claude') {
  const byId = new Map()
  let assistantLines = 0
  for (const line of lines) {
    if (line.type !== 'assistant' || !line.message?.usage) continue
    assistantLines += 1
    byId.set(line.message.id, line.message.usage) // 同一条消息的多行：以最后一行为准
  }
  const sum = { input: 0, cacheRead: 0, cacheWrite: 0, output: 0, thinking: 0 }
  for (const usage of byId.values()) {
    sum.input += usage.input_tokens ?? 0
    sum.cacheRead += usage.cache_read_input_tokens ?? 0
    sum.cacheWrite += usage.cache_creation_input_tokens ?? 0
    sum.output += usage.output_tokens ?? 0
    sum.thinking += usage.output_tokens_details?.thinking_tokens ?? 0
  }
  console.log('assistant lines:', assistantLines, 'unique messages:', byId.size)
  console.log('sum:', JSON.stringify(sum))
} else {
  console.error('usage: probe-usage.mjs <codex|dsh|claude> <file>')
  process.exit(1)
}
