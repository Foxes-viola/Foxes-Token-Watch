﻿// 校准 Claude 思考 token 的估算。
//
// 思路：没有思考块的消息，输出 token 全部是可见内容（正文 + 工具参数），可以用来拟合
// “可见内容的字节 / 字符 → token”的换算系数；再拿记录了精确 thinking_tokens 的消息验证
// “思考 ≈ 输出 − 可见内容折算”的误差。
//
// 只输出数字（长度、token 数、系数），不输出任何文本内容。
// 用法：node scripts/calib-claude.mjs <projects 目录>
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';

const root = process.argv[2];
if (!root) {
  console.error('usage: node calib-claude.mjs <projects dir>');
  process.exit(1);
}

function* walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(full);
    else if (entry.name.endsWith('.jsonl')) yield full;
  }
}

// [ASCII 字节数, 非 ASCII 字符数]
function measure(text) {
  let ascii = 0;
  let wide = 0;
  for (const ch of text ?? '') {
    if (ch.codePointAt(0) < 128) ascii += 1;
    else wide += 1;
  }
  return [ascii, wide];
}

const messages = new Map();
for (const file of walk(root)) {
  const reader = readline.createInterface({ input: fs.createReadStream(file), crlfDelay: Infinity });
  for await (const line of reader) {
    if (!line) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch {
      continue;
    }
    if (row.type !== 'assistant' || !row.message?.id) continue;
    const id = row.message.id;
    let item = messages.get(id);
    if (!item) {
      item = { model: String(row.message.model), output: 0, exact: 0, thinkingBlocks: 0, thinkAscii: 0, thinkWide: 0, textAscii: 0, textWide: 0, toolAscii: 0, toolWide: 0, tools: 0, texts: 0, other: 0, lines: 0, outs: new Set() };
      messages.set(id, item);
    }
    const usage = row.message.usage ?? {};
    item.lines += 1;
    item.outs.add(usage.output_tokens ?? -1);
    item.output = Math.max(item.output, usage.output_tokens ?? 0);
    item.exact = Math.max(item.exact, usage.output_tokens_details?.thinking_tokens ?? usage.output_tokens_details?.reasoning_tokens ?? 0);
    for (const block of Array.isArray(row.message.content) ? row.message.content : []) {
      if (block.type === 'thinking' || block.type === 'redacted_thinking') {
        item.thinkingBlocks += 1;
        const [ascii, wide] = measure(block.thinking);
        item.thinkAscii += ascii;
        item.thinkWide += wide;
      } else if (block.type === 'text') {
        const [ascii, wide] = measure(block.text);
        item.textAscii += ascii;
        item.textWide += wide;
        item.texts += 1;
      } else if (block.type === 'tool_use') {
        const [ascii, wide] = measure(JSON.stringify(block.input ?? {}) + (block.name ?? ''));
        item.toolAscii += ascii;
        item.toolWide += wide;
        item.tools += 1;
      } else {
        item.other += 1;
      }
    }
  }
}

const all = [...messages.values()].filter((item) => item.output > 0);
console.log('messages:', all.length, ' with thinking blocks:', all.filter((item) => item.thinkingBlocks > 0).length, ' with exact:', all.filter((item) => item.exact > 0).length, ' other block types:', all.reduce((sum, item) => sum + item.other, 0));

// 最小二乘：y ≈ X·beta
function fit(rows, features, target) {
  const n = features.length;
  const ata = Array.from({ length: n }, () => new Array(n).fill(0));
  const atb = new Array(n).fill(0);
  for (const row of rows) {
    const x = features.map((feature) => feature(row));
    const y = target(row);
    for (let i = 0; i < n; i += 1) {
      atb[i] += x[i] * y;
      for (let j = 0; j < n; j += 1) ata[i][j] += x[i] * x[j];
    }
  }
  // 高斯消元
  for (let i = 0; i < n; i += 1) {
    let pivot = i;
    for (let r = i + 1; r < n; r += 1) if (Math.abs(ata[r][i]) > Math.abs(ata[pivot][i])) pivot = r;
    [ata[i], ata[pivot]] = [ata[pivot], ata[i]];
    [atb[i], atb[pivot]] = [atb[pivot], atb[i]];
    if (Math.abs(ata[i][i]) < 1e-9) continue;
    for (let r = 0; r < n; r += 1) {
      if (r === i) continue;
      const factor = ata[r][i] / ata[i][i];
      for (let c = i; c < n; c += 1) ata[r][c] -= factor * ata[i][c];
      atb[r] -= factor * atb[i];
    }
  }
  return atb.map((value, i) => (Math.abs(ata[i][i]) < 1e-9 ? 0 : value / ata[i][i]));
}

const features = [
  (item) => item.textAscii,
  (item) => item.textWide,
  (item) => item.toolAscii,
  (item) => item.toolWide,
  (item) => item.tools,
  (item) => item.texts,
];
const names = ['textAscii', 'textWide', 'toolAscii', 'toolWide', 'perTool', 'perText'];
const predict = (beta) => (item) => features.reduce((sum, feature, i) => sum + beta[i] * feature(item), 0);

function report(label, rows, estimate, truth) {
  if (!rows.length) return;
  const sumTruth = rows.reduce((sum, item) => sum + truth(item), 0);
  const sumEstimate = rows.reduce((sum, item) => sum + estimate(item), 0);
  const errors = rows.map((item) => Math.abs(estimate(item) - truth(item)) / Math.max(1, item.output)).sort((a, b) => a - b);
  console.log(
    `  ${label}: n=${rows.length} truth=${Math.round(sumTruth)} estimate=${Math.round(sumEstimate)} (${((sumEstimate / Math.max(1, sumTruth) - 1) * 100).toFixed(1)}%)` +
      ` | per-message abs err / output: median ${(errors[Math.floor(errors.length / 2)] * 100).toFixed(1)}% p90 ${(errors[Math.floor(errors.length * 0.9)] * 100).toFixed(1)}%`,
  );
}

// ── 用记录了精确思考 token 的消息反推“可见内容 → token”的系数（两参数：ASCII 字节、非 ASCII 字符） ──
{
  const exact = all.filter((item) => item.exact > 0);
  const simple = [(item) => item.textAscii + item.toolAscii, (item) => item.textWide + item.toolWide];
  const visible = (item) => item.output - item.exact;
  const beta = fit(exact, simple, visible);
  const apply = (coefficients) => (item) => coefficients[0] * simple[0](item) + coefficients[1] * simple[1](item);
  console.log('\n== exact-thinking messages: fit visible tokens = a*ascii + w*wide');
  console.log(`  n=${exact.length} a=${beta[0].toFixed(3)} w=${beta[1].toFixed(3)}  sums: ascii=${exact.reduce((s, i) => s + simple[0](i), 0)} wide=${exact.reduce((s, i) => s + simple[1](i), 0)} visibleTokens=${exact.reduce((s, i) => s + visible(i), 0)}`);
  const candidates = { fitted: beta, 'a0.27 w1.5': [0.27, 1.5], 'a0.30 w1.5': [0.3, 1.5], 'a0.30 w1.3': [0.3, 1.3], 'a0.33 w1.6': [0.33, 1.6] };
  for (const [label, coefficients] of Object.entries(candidates)) {
    report(`visible on exact [${label}]`, exact, apply(coefficients), visible);
    report(`thinking on exact [${label}]`, exact, (item) => Math.min(item.output, Math.max(0, item.output - apply(coefficients)(item))), (item) => item.exact);
  }
  for (const model of [...new Set(all.map((item) => item.model))]) {
    const plain = all.filter((item) => item.model === model && item.thinkingBlocks === 0);
    if (!plain.length) continue;
    for (const [label, coefficients] of Object.entries({ fitted: beta, 'a0.30 w1.5': [0.3, 1.5] })) {
      report(`${model} no-thinking-block messages, visible [${label}]`, plain, apply(coefficients), (item) => item.output);
      const shares = plain.map((item) => (item.output - apply(coefficients)(item)) / Math.max(1, item.output)).sort((a, b) => a - b);
      const q = (p) => (shares[Math.min(shares.length - 1, Math.floor(shares.length * p))] * 100).toFixed(0);
      console.log(`      unexplained share of output: p10 ${q(0.1)}% p25 ${q(0.25)}% p50 ${q(0.5)}% p75 ${q(0.75)}% p90 ${q(0.9)}%`);
    }
    const sizes = plain.map((item) => item.output).sort((a, b) => a - b);
    console.log(`      output tokens per message: p10 ${sizes[Math.floor(sizes.length * 0.1)]} p50 ${sizes[Math.floor(sizes.length * 0.5)]} p90 ${sizes[Math.floor(sizes.length * 0.9)]}; with tool calls ${plain.filter((item) => item.tools > 0).length}, text only ${plain.filter((item) => item.tools === 0).length}`);
  }
}

for (const model of [...new Set(all.map((item) => item.model))]) {
  const mine = all.filter((item) => item.model === model);
  const plain = mine.filter((item) => item.thinkingBlocks === 0);
  console.log(`\n== ${model}: ${mine.length} messages, ${plain.length} without thinking blocks`);
  if (plain.length < 30) continue;
  // 奇偋分组：一半拟合，一半验证
  const train = plain.filter((_, index) => index % 2 === 0);
  const test = plain.filter((_, index) => index % 2 === 1);
  const beta = fit(train, features, (item) => item.output);
  console.log('  fitted tokens per unit:', names.map((name, i) => `${name}=${beta[i].toFixed(3)}`).join(' '));
  report('held-out visible tokens (fitted)', test, predict(beta), (item) => item.output);
  const fixed = [0.27, 1.0, 0.3, 1.0, 12, 3];
  report('held-out visible tokens (fixed 0.27/1.0/0.30/1.0/12/3)', test, predict(fixed), (item) => item.output);

  const exact = mine.filter((item) => item.exact > 0);
  const thinking = (coefficients) => (item) => Math.min(item.output, Math.max(0, item.output - predict(coefficients)(item)));
  report('thinking on exact messages (fitted)', exact, thinking(beta), (item) => item.exact);
  report('thinking on exact messages (fixed)', exact, thinking(fixed), (item) => item.exact);

  const withThinking = mine.filter((item) => item.thinkingBlocks > 0);
  const sum = (rows, pick) => rows.reduce((total, item) => total + pick(item), 0);
  const output = sum(withThinking, (item) => item.output);
  const residual = sum(withThinking, thinking(beta));
  const summary = sum(withThinking, (item) => item.thinkAscii * beta[0] + item.thinkWide * beta[1]);
  console.log(`  messages with thinking blocks: output=${output} residual-thinking=${Math.round(residual)} (${((residual / Math.max(1, output)) * 100).toFixed(1)}%) thinking-text-as-tokens=${Math.round(summary)} (${((summary / Math.max(1, output)) * 100).toFixed(1)}%)`);
  const negative = withThinking.filter((item) => item.output - predict(beta)(item) < 0).length;
  console.log(`  residual negative on ${negative} of ${withThinking.length}`);
}

if (process.argv.includes('--rows')) {
  const row = (item) => `out=${item.output} exact=${item.exact} thinkBlocks=${item.thinkingBlocks} thinkA=${item.thinkAscii} thinkW=${item.thinkWide} textA=${item.textAscii} textW=${item.textWide} toolA=${item.toolAscii} toolW=${item.toolWide} tools=${item.tools} texts=${item.texts} lines=${item.lines} outs=${[...item.outs].join('/')}`;
  console.log('\n-- exact messages');
  for (const item of all.filter((item) => item.exact > 0)) console.log('  ' + row(item));
  console.log('\n-- sample of no-thinking-block messages (official model)');
  const plain = all.filter((item) => item.model === 'claude-opus-5-5' && item.thinkingBlocks === 0);
  for (let i = 0; i < plain.length; i += Math.ceil(plain.length / 30)) console.log('  ' + row(plain[i]));
}
