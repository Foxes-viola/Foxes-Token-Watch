#!/usr/bin/env python3
"""数据源探测：打印 SQLite 库的表结构和各列的「形状」，用来写和排查解析器。

只读打开，不改库。只输出结构：文本和二进制列只报长度范围；内容是 JSON 的列只报键名；不输出对话内容。

用法：python scripts/probe-sqlite.py <file.db> [--sample N]
"""
import json
import sqlite3
import sys
from pathlib import Path


def json_keys(value, prefix, out, depth=0):
    if isinstance(value, dict) and depth < 3:
        for key, item in value.items():
            json_keys(item, f"{prefix}.{key}" if prefix else key, out, depth + 1)
    elif isinstance(value, list):
        out.add(f"{prefix}[]")
        for item in value[:3]:
            json_keys(item, f"{prefix}[]", out, depth + 1)
    else:
        out.add(f"{prefix}:{type(value).__name__}")


def describe_column(conn, table, column, sample):
    rows = conn.execute(f'SELECT "{column}" FROM "{table}" ORDER BY rowid DESC LIMIT ?', (sample,)).fetchall()
    kinds = {}
    lo, hi = None, None
    keys = set()
    for (value,) in rows:
        kind = type(value).__name__
        kinds[kind] = kinds.get(kind, 0) + 1
        if isinstance(value, (int, float)):
            size = value
        elif isinstance(value, (str, bytes)):
            size = len(value)
            if isinstance(value, str) and value[:1] in "{[":
                try:
                    json_keys(json.loads(value), "", keys)
                except ValueError:
                    pass
        else:
            continue
        lo = size if lo is None else min(lo, size)
        hi = size if hi is None else max(hi, size)
    text = ",".join(f"{k}:{n}" for k, n in kinds.items())
    if lo is not None:
        text += f" range/len={lo}..{hi}"
    if keys:
        shown = sorted(keys)
        text += " json=" + " ".join(shown[:40]) + (" ..." if len(shown) > 40 else "")
    return text


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    path = Path(sys.argv[1])
    sample = int(sys.argv[sys.argv.index("--sample") + 1]) if "--sample" in sys.argv else 200
    conn = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True, timeout=2)
    print(f"# {path.name} size={path.stat().st_size}")
    tables = conn.execute("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') ORDER BY name").fetchall()
    for name, kind in tables:
        try:
            count = conn.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0]
        except sqlite3.Error as error:
            print(f"\n## {kind} {name}: {error}")
            continue
        print(f"\n## {kind} {name} rows={count}")
        for _, column, ctype, *_rest in conn.execute(f'PRAGMA table_info("{name}")').fetchall():
            detail = describe_column(conn, name, column, sample) if count else ""
            print(f"  {column} {ctype} [{detail}]")


if __name__ == "__main__":
    main()
