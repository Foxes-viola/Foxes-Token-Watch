#!/usr/bin/env python3
"""Antigravity 会话库的用量核对（只输出数字、枚举和时间，不输出任何对话内容）。

  python scripts/probe-antigravity.py <conversations 目录>            每个库的汇总
  python scripts/probe-antigravity.py <conversations 目录> --tail N   最近改动的库的最后 N 步
"""
import os
import sqlite3
import sys
import time


def read_varint(buf, pos):
    result = 0
    shift = 0
    while True:
        byte = buf[pos]
        pos += 1
        result |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return result, pos
        shift += 7


def parse(buf):
    """返回 [(field, wire_type, value)]；解析失败返回 None。"""
    out = []
    pos = 0
    try:
        while pos < len(buf):
            key, pos = read_varint(buf, pos)
            field, wire = key >> 3, key & 7
            if field == 0:
                return None
            if wire == 0:
                value, pos = read_varint(buf, pos)
            elif wire == 1:
                value = buf[pos:pos + 8]
                pos += 8
            elif wire == 2:
                size, pos = read_varint(buf, pos)
                if pos + size > len(buf):
                    return None
                value = buf[pos:pos + size]
                pos += size
            elif wire == 5:
                value = buf[pos:pos + 4]
                pos += 4
            else:
                return None
            out.append((field, wire, value))
    except IndexError:
        return None
    return out


def first(fields, number):
    for field, _wire, value in fields:
        if field == number:
            return value
    return None


def timestamp(fields, number):
    raw = first(fields, number)
    if not isinstance(raw, (bytes, bytearray)):
        return None
    inner = parse(raw)
    if not inner:
        return None
    seconds = first(inner, 1) or 0
    nanos = first(inner, 2) or 0
    return seconds + nanos / 1e9


def usage_of(metadata):
    fields = parse(metadata) if metadata else None
    if not fields:
        return None, fields
    raw = first(fields, 9)
    if not isinstance(raw, (bytes, bytearray)):
        return None, fields
    inner = parse(raw)
    if not inner:
        return None, fields
    numbers = {field: value for field, wire, value in inner if wire == 0}
    return numbers, fields


def open_ro(path):
    return sqlite3.connect('file:' + path.replace('\\', '/') + '?mode=ro', uri=True)


def summarize(path):
    conn = open_ro(path)
    totals = {2: 0, 3: 0, 4: 0, 5: 0, 9: 0, 10: 0}
    with_usage = 0
    mismatch = 0
    seen_keys = set()
    models = {}
    first_time = None
    last_time = None
    rows = conn.execute('select idx, step_type, status, metadata from steps order by idx').fetchall()
    for _idx, _step_type, _status, metadata in rows:
        usage, fields = usage_of(metadata)
        if fields:
            created = timestamp(fields, 1)
            if created:
                first_time = created if first_time is None else min(first_time, created)
                last_time = created if last_time is None else max(last_time, created)
        if not usage:
            continue
        with_usage += 1
        seen_keys.update(usage.keys())
        for key in totals:
            totals[key] += usage.get(key, 0)
        if usage.get(9, 0) + usage.get(10, 0) != usage.get(3, 0):
            mismatch += 1
        models[usage.get(1)] = models.get(usage.get(1), 0) + 1
    conn.close()
    return {
        'steps': len(rows),
        'with_usage': with_usage,
        'mismatch_9+10!=3': mismatch,
        'usage_keys': sorted(seen_keys),
        'in': totals[2], 'out': totals[3], 'f4': totals[4], 'cache_read': totals[5],
        'thinking': totals[9], 'response': totals[10],
        'models': models,
        'first': time.strftime('%m-%d %H:%M', time.localtime(first_time)) if first_time else None,
        'last': time.strftime('%m-%d %H:%M', time.localtime(last_time)) if last_time else None,
    }


def tail(path, count):
    conn = open_ro(path)
    rows = conn.execute('select idx, step_type, status, metadata from steps order by idx desc limit ?', (count,)).fetchall()
    now = time.time()
    for idx, step_type, status, metadata in rows:
        usage, fields = usage_of(metadata)
        times = {}
        tool = None
        if fields:
            for number in (1, 6, 7, 8, 32):
                value = timestamp(fields, number)
                if value:
                    times[number] = round(now - value, 1)
            raw_tool = first(fields, 4)
            if isinstance(raw_tool, (bytes, bytearray)):
                inner = parse(raw_tool)
                name = first(inner, 2) if inner else None
                tool = name.decode('utf-8', 'replace') if isinstance(name, (bytes, bytearray)) else None
            field3 = first(fields, 3)
        else:
            field3 = None
        print(f'  idx={idx} type={step_type} status={status} meta.3={field3} tool={tool} age_s={times} usage={usage}')
    conn.close()


def main():
    directory = sys.argv[1]
    files = [os.path.join(directory, name) for name in os.listdir(directory) if name.endswith('.db')]
    files.sort(key=os.path.getmtime, reverse=True)
    if '--tail' in sys.argv:
        count = int(sys.argv[sys.argv.index('--tail') + 1])
        for path in files[:2]:
            age = time.time() - os.path.getmtime(path)
            wal = path + '-wal'
            wal_age = round(time.time() - os.path.getmtime(wal)) if os.path.exists(wal) else None
            print(f'# {os.path.basename(path)[:8]}  db_age_s={round(age)} wal_age_s={wal_age}')
            tail(path, count)
        return
    for path in files:
        try:
            print(os.path.basename(path)[:8], summarize(path))
        except sqlite3.Error as error:
            print(os.path.basename(path)[:8], 'error:', error)


if __name__ == '__main__':
    main()
