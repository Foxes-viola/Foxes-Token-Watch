#!/usr/bin/env python3
"""数据源探测：在没有 .proto 定义的情况下，按 protobuf 线格式打印 SQLite BLOB 列的字段树。

用来找 Antigravity 会话库里 token 用量在哪个字段号。只读打开，不改库。
只输出结构：整数字段显示数值，字符串只显示长度（像标识符的短串除外，如模型名），不输出对话内容。

用法：
  python scripts/probe-protobuf.py <file.db> --counts                 各表行数
  python scripts/probe-protobuf.py <file.db> <table> <column> [--rows N] [--depth N] [--where SQL]
"""
import re
import sqlite3
import sys
from pathlib import Path

IDENT = re.compile(r"^[A-Za-z0-9_.:/@+-]{1,48}$")


def read_varint(buf, pos):
    result = 0
    shift = 0
    while True:
        if pos >= len(buf) or shift > 63:
            raise ValueError("bad varint")
        byte = buf[pos]
        pos += 1
        result |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return result, pos
        shift += 7


def parse(buf):
    """返回 [(字段号, 线类型, 值)]；不是合法的 protobuf 消息时抛 ValueError。"""
    fields = []
    pos = 0
    while pos < len(buf):
        key, pos = read_varint(buf, pos)
        number, wire = key >> 3, key & 7
        if number == 0 or number > 536870911:
            raise ValueError("bad field number")
        if wire == 0:
            value, pos = read_varint(buf, pos)
        elif wire == 1:
            value, pos = buf[pos:pos + 8], pos + 8
        elif wire == 2:
            size, pos = read_varint(buf, pos)
            if pos + size > len(buf):
                raise ValueError("truncated")
            value, pos = buf[pos:pos + size], pos + size
        elif wire == 5:
            value, pos = buf[pos:pos + 4], pos + 4
        else:
            raise ValueError("unsupported wire type")
        if pos > len(buf):
            raise ValueError("truncated")
        fields.append((number, wire, value))
    return fields


def describe(buf, indent, depth, max_depth, out):
    for number, wire, value in parse(buf):
        pad = "  " * indent
        if wire == 0:
            out.append(f"{pad}{number}: varint {value}")
        elif wire in (1, 5):
            out.append(f"{pad}{number}: fixed{len(value) * 8} 0x{value[::-1].hex()}")
        else:
            nested = None
            if value and depth < max_depth:
                try:
                    nested = parse(value)
                except ValueError:
                    nested = None
            text = None
            try:
                text = value.decode("utf-8")
            except UnicodeDecodeError:
                pass
            if text is not None and IDENT.match(text):
                out.append(f"{pad}{number}: str '{text}'")
            elif nested:
                out.append(f"{pad}{number}: msg len={len(value)}")
                describe(value, indent + 1, depth + 1, max_depth, out)
            elif text is not None:
                out.append(f"{pad}{number}: str len={len(text)}")
            else:
                out.append(f"{pad}{number}: bytes len={len(value)}")


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return
    path = Path(args[0])
    conn = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True, timeout=2)
    if "--counts" in args:
        names = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        print(path.name, " ".join(f"{n}={conn.execute(f'SELECT COUNT(*) FROM \"{n}\"').fetchone()[0]}" for n in names))
        return
    table, column = args[1], args[2]
    rows = int(args[args.index("--rows") + 1]) if "--rows" in args else 2
    max_depth = int(args[args.index("--depth") + 1]) if "--depth" in args else 6
    where = "WHERE " + args[args.index("--where") + 1] if "--where" in args else ""
    query = f'SELECT rowid, "{column}" FROM "{table}" {where} ORDER BY rowid DESC LIMIT ?'
    for rowid, blob in conn.execute(query, (rows,)):
        print(f"# {table}.{column} rowid={rowid} len={len(blob) if blob is not None else None}")
        if blob is None:
            continue
        out = []
        try:
            describe(bytes(blob), 1, 0, max_depth, out)
        except ValueError as error:
            out.append(f"  (not protobuf: {error})")
        print("\n".join(out))


if __name__ == "__main__":
    main()
