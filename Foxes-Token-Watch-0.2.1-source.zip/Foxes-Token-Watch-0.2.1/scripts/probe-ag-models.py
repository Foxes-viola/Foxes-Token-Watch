"""反重力：按模型枚举列出 gen_metadata 里可能是模型名的短字符串（只显示标识符样式的短值，不显示正文）。

用法：python scripts/probe-ag-models.py <conversations 目录>
"""
import glob
import os
import re
import sqlite3
import sys

IDENT = re.compile(rb"^[A-Za-z0-9_.:/@+ -]{2,64}$")


def varint(buf, pos):
    value = 0
    shift = 0
    while pos < len(buf):
        byte = buf[pos]
        pos += 1
        value |= (byte & 0x7F) << shift
        if byte < 0x80:
            return value, pos
        shift += 7
        if shift > 63:
            break
    raise ValueError("bad varint")


def fields(buf):
    pos = 0
    out = []
    try:
        while pos < len(buf):
            key, pos = varint(buf, pos)
            number, wire = key >> 3, key & 7
            if number == 0:
                return out
            if wire == 0:
                value, pos = varint(buf, pos)
            elif wire == 1:
                value, pos = buf[pos:pos + 8], pos + 8
            elif wire == 2:
                size, pos = varint(buf, pos)
                if pos + size > len(buf):
                    return out
                value, pos = buf[pos:pos + size], pos + size
            elif wire == 5:
                value, pos = buf[pos:pos + 4], pos + 4
            else:
                return out
            out.append((number, wire, value))
    except ValueError:
        pass
    return out


def first(buf, number, wire=None):
    for n, w, value in fields(buf):
        if n == number and (wire is None or w == wire):
            return value
    return None


def describe(buf, prefix, depth, out):
    for number, wire, value in fields(buf):
        path = f"{prefix}.{number}" if prefix else str(number)
        if wire == 0:
            out.append(f"{path}=varint:{value}")
        elif wire == 2:
            if IDENT.match(value):
                out.append(f"{path}=str:{value.decode()}")
            elif depth < 2 and len(value) < 4096 and fields(value):
                describe(value, path, depth + 1, out)
            else:
                out.append(f"{path}=bytes[{len(value)}]")


def main():
    root = sys.argv[1]
    seen = {}
    for path in sorted(glob.glob(os.path.join(root, "*.db"))):
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            rows = conn.execute("SELECT idx, metadata FROM steps WHERE step_type = 15 ORDER BY idx").fetchall()
        except sqlite3.Error:
            conn.close()
            continue
        for _idx, metadata in rows:
            if not metadata:
                continue
            usage = first(metadata, 9, 2)
            link = first(metadata, 20, 2)
            if usage is None or link is None:
                continue
            enum = first(usage, 1, 0)
            gen_idx = first(link, 3, 0)
            if enum is None or gen_idx is None:
                continue
            entry = seen.setdefault(enum, {"count": 0, "names": {}, "sample": None})
            entry["count"] += 1
            if entry["count"] > 3 and entry["sample"] is not None:
                continue
            row = conn.execute("SELECT data FROM gen_metadata WHERE idx = ?", (gen_idx,)).fetchone()
            if not row or not row[0]:
                continue
            inner = first(row[0], 1, 2)
            if inner is None:
                continue
            name = first(inner, 19, 2)
            label = name.decode() if name is not None and IDENT.match(name) else f"<{'none' if name is None else 'len ' + str(len(name))}>"
            entry["names"][label] = entry["names"].get(label, 0) + 1
            if entry["sample"] is None:
                # 只看顶层的短字段：变长字段超过 4 KB 的只记长度
                out = []
                for number, wire, value in fields(inner):
                    if wire == 0:
                        out.append(f"{number}=varint:{value}")
                    elif wire == 2:
                        if IDENT.match(value):
                            out.append(f"{number}=str:{value.decode()}")
                        elif len(value) <= 512:
                            nested = []
                            describe(value, str(number), 1, nested)
                            out.extend(nested if nested else [f"{number}=bytes[{len(value)}]"])
                        else:
                            out.append(f"{number}=bytes[{len(value)}]")
                entry["sample"] = out
        conn.close()
    for enum, entry in sorted(seen.items()):
        print(f"enum {enum}: generations {entry['count']}  field-19 values {entry['names']}")
        if entry["sample"]:
            shown = [item for item in entry["sample"] if "bytes[" not in item][:40]
            print("   top-level short fields:", "; ".join(shown))


main()
