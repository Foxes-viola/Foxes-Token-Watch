// 开发用：连到带 --remote-debugging-port 启动的软件窗口，执行一段脚本或截一张图。
//   node scripts/cdp.mjs <端口> <网址片段> eval "<表达式>"
//   node scripts/cdp.mjs <端口> <网址片段> shot <输出.png>
// 启动方式：$env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS='--remote-debugging-port=9223'; .\target\debug\Foxes-Token-Watch.exe
import { writeFileSync } from 'node:fs'

const [port, match, action, argument] = process.argv.slice(2)
if (!port || !match || !action) {
  console.error('usage: node scripts/cdp.mjs <port> <url-part> eval <expr> | shot <file>')
  process.exit(2)
}

const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()
const target = list.find((item) => item.type === 'page' && item.url.endsWith(match))
if (!target) {
  console.error('no such page; open pages:', list.map((item) => item.url).join(', '))
  process.exit(1)
}

const socket = new WebSocket(target.webSocketDebuggerUrl)
const pending = new Map()
let nextId = 0
socket.onmessage = (event) => {
  const message = JSON.parse(event.data)
  const resolve = pending.get(message.id)
  if (resolve) {
    pending.delete(message.id)
    resolve(message)
  }
}
await new Promise((resolve, reject) => {
  socket.onopen = resolve
  socket.onerror = reject
})

function send(method, params = {}) {
  return new Promise((resolve) => {
    const id = ++nextId
    pending.set(id, resolve)
    socket.send(JSON.stringify({ id, method, params }))
  })
}

if (action === 'eval') {
  const reply = await send('Runtime.evaluate', { expression: argument, returnByValue: true, awaitPromise: true })
  const result = reply.result?.exceptionDetails ?? reply.result?.result?.value ?? reply.result ?? reply.error
  console.log(typeof result === 'string' ? result : JSON.stringify(result, null, 2))
} else if (action === 'shot') {
  const reply = await send('Page.captureScreenshot', { format: 'png' })
  if (!reply.result?.data) {
    console.error('screenshot failed:', JSON.stringify(reply.error ?? reply))
    process.exit(1)
  }
  writeFileSync(argument, Buffer.from(reply.result.data, 'base64'))
  console.log('saved', argument)
} else if (action === 'move' || action === 'click') {
  // 合成的鼠标事件，不会移动真实的鼠标指针；坐标是页面内的 CSS 像素 "x,y"
  const [x, y] = argument.split(',').map(Number)
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
  if (action === 'click') {
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 })
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 })
  }
  console.log(action, x, y)
} else {
  console.error('unknown action', action)
  process.exit(2)
}

socket.close()
