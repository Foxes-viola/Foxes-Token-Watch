#!/usr/bin/env node
// 数据源探测：打印 JSONL / JSON 文件的「形状」（键路径、类型、数值范围），用来写和排查各 agent 的解析器。
// 只输出结构，不输出对话内容：字符串只记长度，只有白名单里的短字段（类型、模型名之类）才显示取值。
//
// 用法：
//   node scripts/probe-shape.mjs <file> [--max-lines N] [--depth N]
//   node scripts/probe-shape.mjs --newest <dir> [--ext .jsonl] [--count N]   列出目录下最近修改的文件

import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'
import zlib from 'node:zlib'

const SHOW_VALUES = new Set([
  'type', 'subtype', 'role', 'model', 'stop_reason', 'service_tier', 'status', 'kind', 'name', 'event',
  'originator', 'cli_version', 'version', 'effort', 'model_provider', 'provider', 'source', 'phase', 'level',
  'userType', 'entrypoint', 'isSidechain', 'approval_policy', 'sandbox_mode', 'reasoning_effort', 'finish_reason'
])

function parseArgs(argv) {
  const args = { _: [] }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a.startsWith('--')) args[a.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : true
    else args._.push(a)
  }
  return args
}

function walkFiles(dir, ext, out) {
  let entries
  try { entries = fs.readdirSync(dir, { withFileTypes: true }) } catch { return out }
  for (const e of entries) {
    const full = path.join(dir, e.name)
    if (e.isDirectory()) walkFiles(full, ext, out)
    else if (!ext || e.name.endsWith(ext)) {
      try { const st = fs.statSync(full); out.push({ full, size: st.size, mtime: st.mtimeMs }) } catch { /* 文件刚被删掉 */ }
    }
  }
  return out
}

function record(stats, key, kind, value) {
  let s = stats.get(key)
  if (!s) { s = { kinds: new Map(), min: Infinity, max: -Infinity, values: new Map() }; stats.set(key, s) }
  s.kinds.set(kind, (s.kinds.get(kind) || 0) + 1)
  if (kind === 'number') { s.min = Math.min(s.min, value); s.max = Math.max(s.max, value) }
  if (kind === 'string') { s.min = Math.min(s.min, value.length); s.max = Math.max(s.max, value.length) }
  const leaf = key.split('.').pop().replace(/\[\]$/, '')
  // 只展示标识符样式的短值；带空格或非 ASCII 的（会话名、标题等）一律只记长度
  const identifierLike = kind === 'string' && /^[A-Za-z0-9_.:/@+-]{1,48}$/.test(value)
  if ((identifierLike && SHOW_VALUES.has(leaf)) || kind === 'boolean') {
    if (s.values.size < 14) s.values.set(String(value), (s.values.get(String(value)) || 0) + 1)
  }
}

function shape(value, key, stats, depth, maxDepth) {
  if (value === null) return record(stats, key, 'null')
  if (Array.isArray(value)) {
    record(stats, key, 'array')
    for (const item of value.slice(0, 8)) shape(item, key + '[]', stats, depth + 1, maxDepth)
    return
  }
  const kind = typeof value
  if (kind === 'object') {
    if (depth >= maxDepth) return record(stats, key, 'object')
    for (const k of Object.keys(value)) shape(value[k], key ? key + '.' + k : k, stats, depth + 1, maxDepth)
    return
  }
  record(stats, key, kind, value)
}

function groupOf(obj) {
  const parts = [obj.type]
  const p = obj.payload
  if (p && typeof p === 'object' && typeof p.type === 'string') parts.push(p.type)
  const m = obj.message
  if (m && typeof m === 'object' && typeof m.role === 'string') parts.push(m.role)
  if (typeof obj.subtype === 'string') parts.push(obj.subtype)
  return parts.filter(Boolean).join(' / ') || '(no type)'
}

function printGroup(name, count, stats) {
  console.log(`\n## ${name}  x${count}`)
  for (const [key, s] of [...stats.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
    const kinds = [...s.kinds.entries()].map(([k, n]) => `${k}:${n}`).join(',')
    let extra = ''
    if (s.kinds.has('number')) extra += ` range=${s.min}..${s.max}`
    else if (s.kinds.has('string')) extra += ` len=${s.min}..${s.max}`
    if (s.values.size) extra += ' values=' + [...s.values.entries()].map(([v, n]) => `${v}(${n})`).join('|')
    console.log(`  ${key}  [${kinds}]${extra}`)
  }
}

/**
 * 会话文件是边写边追加的，每次追加是一个独立的 zstd 帧；zstdDecompressSync 只解第一帧，所以先按帧切开。
 * 帧格式见 RFC 8878：魔数 + 帧头 + 若干块（每块 3 字节头）+ 可选的 4 字节校验。
 */
function splitZstdFrames(buf) {
  const frames = []
  let pos = 0
  while (pos + 4 <= buf.length) {
    const start = pos
    const magic = buf.readUInt32LE(pos)
    if ((magic & 0xfffffff0) === 0x184d2a50) { // 可跳过帧：不含数据
      pos += 8 + buf.readUInt32LE(pos + 4)
      continue
    }
    if (magic !== 0xfd2fb528) throw new Error(`not a zstd frame at offset ${pos}`)
    const descriptor = buf[pos + 4]
    const fcsFlag = descriptor >> 6
    const singleSegment = (descriptor >> 5) & 1
    const hasChecksum = (descriptor >> 2) & 1
    const dictIdSize = [0, 1, 2, 4][descriptor & 3]
    const fcsSize = fcsFlag === 0 ? singleSegment : [0, 2, 4, 8][fcsFlag]
    pos += 5 + (singleSegment ? 0 : 1) + dictIdSize + fcsSize
    for (;;) {
      const header = buf[pos] | (buf[pos + 1] << 8) | (buf[pos + 2] << 16)
      const last = header & 1
      const type = (header >> 1) & 3
      const size = header >> 3
      pos += 3 + (type === 1 ? 1 : size) // RLE 块只存 1 个字节
      if (last) break
    }
    if (hasChecksum) pos += 4
    frames.push(buf.subarray(start, pos))
  }
  return frames
}

async function probeFile(file, maxLines, maxDepth) {
  const st = fs.statSync(file)
  console.log(`# ${path.basename(file)}  size=${st.size}  mtime=${new Date(st.mtimeMs).toISOString()}`)
  const groups = new Map()
  const add = obj => {
    const g = groupOf(obj)
    let entry = groups.get(g)
    if (!entry) { entry = { count: 0, stats: new Map() }; groups.set(g, entry) }
    entry.count++
    shape(obj, '', entry.stats, 0, maxDepth)
  }
  if (file.endsWith('.jsonl.zstd') || file.endsWith('.jsonl.zst')) {
    // Deepseek Harness 的会话是 zstd 压缩的 JSONL（Node 22.15+ 自带解压）
    const frames = splitZstdFrames(fs.readFileSync(file))
    const text = frames.map(frame => zlib.zstdDecompressSync(frame).toString('utf8')).join('')
    console.log(`zstdFrames=${frames.length}`)
    let n = 0
    let bad = 0
    for (const line of text.split('\n')) {
      if (!line.trim()) continue
      if (++n > maxLines) break
      try { add(JSON.parse(line)) } catch { bad++ }
    }
    console.log(`lines=${Math.min(n, maxLines)} unparsable=${bad} rawBytes=${text.length}`)
  } else if (!file.endsWith('.jsonl')) {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'))
    for (const item of Array.isArray(parsed) ? parsed.slice(0, maxLines) : [parsed]) add(item)
  } else {
    const rl = readline.createInterface({ input: fs.createReadStream(file, 'utf8'), crlfDelay: Infinity })
    let n = 0
    let bad = 0
    for await (const line of rl) {
      if (!line.trim()) continue
      if (++n > maxLines) break
      try { add(JSON.parse(line)) } catch { bad++ }
    }
    console.log(`lines=${Math.min(n, maxLines)} unparsable=${bad}`)
  }
  for (const [name, entry] of groups) printGroup(name, entry.count, entry.stats)
}

const args = parseArgs(process.argv.slice(2))
if (args.newest) {
  const files = walkFiles(String(args.newest), args.ext === true ? '' : (args.ext || ''), [])
  files.sort((a, b) => b.mtime - a.mtime)
  console.log(`files=${files.length} totalMB=${(files.reduce((s, f) => s + f.size, 0) / 1048576).toFixed(1)}`)
  for (const f of files.slice(0, Number(args.count) || 8)) {
    console.log(`${new Date(f.mtime).toISOString()}  ${String(f.size).padStart(10)}  ${f.full}`)
  }
} else if (args._[0]) {
  await probeFile(args._[0], Number(args['max-lines']) || 3000, Number(args.depth) || 4)
} else {
  console.log('usage: probe-shape.mjs <file> [--max-lines N] [--depth N] | --newest <dir> [--ext .jsonl] [--count N]')
}
