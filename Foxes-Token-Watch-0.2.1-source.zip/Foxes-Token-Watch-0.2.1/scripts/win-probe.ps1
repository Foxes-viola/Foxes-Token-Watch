# Dev helper: inspect the Foxes Token Watch windows, or capture only the screen area of one of its own windows.
#   powershell -File scripts\win-probe.ps1 list
#   powershell -File scripts\win-probe.ps1 shot -title <part> -out <file.png>
#   powershell -File scripts\win-probe.ps1 hit -title <part> -a <dx> -b <dy>
#   powershell -File scripts\win-probe.ps1 region -title <part> -a <x> -b <y> -c <w> -d <h>
param([string]$action = 'list', [string]$title = '', [int]$a = 0, [int]$b = 0, [int]$c = 0, [int]$d = 0, [string]$out = '')

[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class FwWin {
  public delegate bool EnumProc(IntPtr hwnd, IntPtr lparam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc proc, IntPtr lparam);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int max);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
  [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")] public static extern IntPtr GetWindowLongPtr(IntPtr hwnd, int index);
  [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT point);
  [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
  [DllImport("user32.dll")] public static extern int SetWindowRgn(IntPtr hwnd, IntPtr region, bool redraw);
  [DllImport("gdi32.dll")] public static extern IntPtr CreateRectRgn(int left, int top, int right, int bottom);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  public static List<IntPtr> Windows(uint pid) {
    var list = new List<IntPtr>();
    EnumWindows((hwnd, l) => { uint owner; GetWindowThreadProcessId(hwnd, out owner); if (owner == pid) list.Add(hwnd); return true; }, IntPtr.Zero);
    return list;
  }
  public static string Title(IntPtr hwnd) { var text = new StringBuilder(256); GetWindowText(hwnd, text, 256); return text.ToString(); }
}
"@
[void][FwWin]::SetProcessDPIAware()

$process = Get-Process -Name 'Foxes-Token-Watch' -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $process) { 'Foxes Token Watch is not running'; exit 1 }
$windows = [FwWin]::Windows([uint32]$process.Id) | Where-Object { [FwWin]::Title($_) -ne '' }

function Find-Window([string]$part) {
  $exact = $windows | Where-Object { [FwWin]::Title($_) -eq $part } | Select-Object -First 1
  if ($exact) { return $exact }
  $windows | Where-Object { [FwWin]::Title($_) -like "*$part*" } | Select-Object -First 1
}

function Get-Rect($hwnd) {
  $rect = New-Object FwWin+RECT
  [void][FwWin]::GetWindowRect($hwnd, [ref]$rect)
  $rect
}

if ($action -eq 'list') {
  foreach ($hwnd in $windows) {
    $rect = Get-Rect $hwnd
    $ex = [FwWin]::GetWindowLongPtr($hwnd, -20).ToInt64()
    '{0} [{1}] visible={2} rect=({3},{4}) {5}x{6} exstyle=0x{7:X8} toolwindow={8} noactivate={9} topmost={10}' -f $hwnd, [FwWin]::Title($hwnd), [FwWin]::IsWindowVisible($hwnd), $rect.Left, $rect.Top, ($rect.Right - $rect.Left), ($rect.Bottom - $rect.Top), $ex, (($ex -band 0x80) -ne 0), (($ex -band 0x08000000) -ne 0), (($ex -band 0x8) -ne 0)
  }
  exit 0
}

$hwnd = Find-Window $title
if (-not $hwnd) { "no window titled like '$title'"; exit 1 }
$rect = Get-Rect $hwnd

if ($action -eq 'shot') {
  $width = $rect.Right - $rect.Left
  $height = $rect.Bottom - $rect.Top
  $bitmap = New-Object Drawing.Bitmap $width, $height
  $graphics = [Drawing.Graphics]::FromImage($bitmap)
  $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, $bitmap.Size)
  $bitmap.Save($out, [Drawing.Imaging.ImageFormat]::Png)
  $graphics.Dispose(); $bitmap.Dispose()
  "saved $out ($width x $height)"
} elseif ($action -eq 'hit') {
  $point = New-Object FwWin+POINT
  $point.X = $rect.Left + $a
  $point.Y = $rect.Top + $b
  $found = [FwWin]::WindowFromPoint($point)
  $root = [FwWin]::GetAncestor($found, 2)
  $owner = 0
  [void][FwWin]::GetWindowThreadProcessId($root, [ref]$owner)
  'point ({0},{1}) -> ours={2}' -f $point.X, $point.Y, ($owner -eq $process.Id)
} elseif ($action -eq 'region') {
  $region = if ($c -gt 0 -and $d -gt 0) { [FwWin]::CreateRectRgn($a, $b, $a + $c, $b + $d) } else { [IntPtr]::Zero }
  $result = [FwWin]::SetWindowRgn($hwnd, $region, $true)
  "SetWindowRgn -> $result"
} else {
  "unknown action $action"
}
