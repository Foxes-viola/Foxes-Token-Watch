// 列出 JSONL 里指定行类型的键路径和值类型（不输出任何值）。
// 用法：node scripts/probe-keys.mjs <目录> <类型,类型,...> [最多文件数]
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';

const [root, typeList, maxFiles = '6'] = process.argv.slice(2);
const wanted = new Set((typeList ?? '').split(','));

function* walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(full);
    else if (entry.name.endsWith('.jsonl')) yield full;
  }
}

const files = [...walk(root)].map((file) => ({ file, mtime: fs.statSync(file).mtimeMs })).sort((a, b) => b.mtime - a.mtime).slice(0, Number(maxFiles));
const shapes = new Map();

function visit(value, prefix, into, depth) {
  if (depth > 5) return;
  if (Array.isArray(value)) {
    into.set(`${prefix}[]`, (into.get(`${prefix}[]`) ?? 0) + 1);
    for (const item of value.slice(0, 3)) visit(item, `${prefix}[]`, into, depth + 1);
  } else if (value && typeof value === 'object') {
    for (const [key, child] of Object.entries(value)) {
      const safeKey = /^[A-Za-z0-9_.-]{1,40}$/.test(key) ? key : '<key>';
      visit(child, prefix ? `${prefix}.${safeKey}` : safeKey, into, depth + 1);
    }
  } else {
    const kind = value === null ? 'null' : typeof value;
    const label = `${prefix}: ${kind}`;
    into.set(label, (into.get(label) ?? 0) + 1);
  }
}

for (const { file } of files) {
  const reader = readline.createInterface({ input: fs.createReadStream(file), crlfDelay: Infinity });
  for await (const line of reader) {
    if (!line) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch {
      continue;
    }
    const type = row.type === 'system' ? `system/${row.subtype}` : String(row.type);
    if (!wanted.has(type)) continue;
    let into = shapes.get(type);
    if (!into) shapes.set(type, (into = new Map([['#lines', 0]])));
    into.set('#lines', into.get('#lines') + 1);
    visit(row, '', into, 0);
  }
}

for (const [type, into] of shapes) {
  console.log(`== ${type} (${into.get('#lines')} lines)`);
  for (const [label, count] of into) if (label !== '#lines') console.log(`  ${label}  x${count}`);
}
