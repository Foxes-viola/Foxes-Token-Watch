#!/usr/bin/env node
// Codex：token_usage_record 与 token_count 的对应关系（只输出数字和字段名）。
//   node scripts/probe-codex-pairs.mjs <rollout.jsonl> [--seq]
import fs from 'node:fs'

const file = process.argv[2]
const showSeq = process.argv.includes('--seq')
const lines = fs.readFileSync(file, 'utf8').split('\n')

const threads = new Map()
const responseIds = new Map()
let sessionId = ''
let records = 0
let recordSum = 0
let counts = 0
let countNull = 0
let countSum = 0
let countDup = 0
let lastCountTotal = -1
let lastRecord = null
let matched = 0
let unmatchedCounts = 0
let recordKeys = new Set()
const seq = []
const recordFieldSets = new Map()
const models = new Map()

for (const raw of lines) {
  if (!raw) continue
  let line
  try {
    line = JSON.parse(raw)
  } catch {
    continue
  }
  const payload = line.payload || {}
  if (line.type === 'session_meta') {
    sessionId = payload.id || sessionId
  } else if (line.type === 'token_usage_record') {
    records++
    const usage = payload.usage || {}
    recordSum += usage.total_tokens || 0
    const thread = payload.thread_id || ''
    const info = threads.get(thread) || { n: 0, sum: 0, isSession: thread === sessionId || thread === payload.session_id }
    info.n++
    info.sum += usage.total_tokens || 0
    threads.set(thread, info)
    const rid = payload.response_id || ''
    responseIds.set(rid, (responseIds.get(rid) || 0) + 1)
    const keys = Object.keys(payload).sort().join(',')
    recordFieldSets.set(keys, (recordFieldSets.get(keys) || 0) + 1)
    const model = typeof payload.model === 'string' && /^[\w.:\/-]{1,48}$/.test(payload.model) ? payload.model : '(none)'
    models.set(model, (models.get(model) || 0) + 1)
    lastRecord = { total: usage.total_tokens || 0, threadTotal: (payload.thread_token_usage || {}).total_tokens ?? null, thread }
    seq.push(`R${threads.size > 1 ? [...threads.keys()].indexOf(thread) : ''}`)
  } else if (line.type === 'event_msg' && payload.type === 'token_count') {
    const info = payload.info
    if (!info) {
      countNull++
      continue
    }
    counts++
    const total = (info.total_token_usage || {}).total_tokens || 0
    const last = (info.last_token_usage || {}).total_tokens || 0
    if (total === lastCountTotal) {
      countDup++
      seq.push('c')
      continue
    }
    lastCountTotal = total
    countSum += last
    if (lastRecord && lastRecord.total === last) {
      matched++
      seq.push('C')
    } else {
      unmatchedCounts++
      seq.push('X')
    }
  }
}

console.log(`records ${records} sum ${recordSum}  distinct response ids ${responseIds.size} (repeated ${[...responseIds.values()].filter((n) => n > 1).length}, empty ${responseIds.get('') || 0})`)
console.log(`token_count: with info ${counts} (null info ${countNull})  unique-by-total ${counts - countDup} sum(last) ${countSum}  duplicates ${countDup}`)
console.log(`token_count whose last == preceding record usage: ${matched}; not matching: ${unmatchedCounts}`)
console.log(`threads in records: ${threads.size}`)
let index = 0
for (const info of threads.values()) {
  console.log(`  thread #${index++}: records ${info.n} sum ${info.sum} same-as-session ${info.isSession}`)
}
console.log('record models:', JSON.stringify(Object.fromEntries(models)))
for (const [keys, n] of recordFieldSets) console.log(`record payload keys x${n}: ${keys}`)
if (showSeq) console.log(seq.join(' ').slice(0, 3000))
