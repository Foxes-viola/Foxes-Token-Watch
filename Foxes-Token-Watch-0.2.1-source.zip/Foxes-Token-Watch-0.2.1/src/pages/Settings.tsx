import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { AgentBadge, Card, FoxLogo, Segmented, Switch } from '../components/ui'
import { fetchAppInfo, quitApp, setIslandDock, useIslandDock, updateSettings, useSettings } from '../lib/api'
import { AGENT_META, fmtBytes, fmtFull, fmtMs } from '../lib/format'
import { AGENTS } from '../lib/types'
import type { AppInfo, Snapshot } from '../lib/types'

function Row({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <div className="set-row">
      <div className="set-text">
        <div className="set-title">{title}</div>
        {hint ? <div className="set-hint muted">{hint}</div> : null}
      </div>
      <div className="set-control">{children}</div>
    </div>
  )
}

export function SettingsPage({ snapshot }: { snapshot: Snapshot }) {
  const settings = useSettings()
  const dock = useIslandDock()
  const [info, setInfo] = useState<AppInfo | null>(null)

  useEffect(() => {
    const load = () => void fetchAppInfo().then(setInfo)
    load()
    // 运行期间新装的 agent 会被自动发现，这里跟着刷新数据目录
    const timer = window.setInterval(load, 5000)
    return () => window.clearInterval(timer)
  }, [])

  const scan = snapshot.scan

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>设置</h1>
          <p className="muted">改动立即生效，自动保存</p>
        </div>
      </header>

      <div className="grid">
        <Card title="灵动岛与后台" className="span-6">
          <Row title="显示灵动岛" hint="悬停查看用量，点击打开面板。拖到屏幕左右边缘松手即可停靠，拖回屏幕中间可自由放置。">
            <Switch on={settings.island} onChange={(island) => void updateSettings({ island })} />
          </Row>
          <Row title="灵动岛位置">
            <div className="card-tools">
              <button className="btn" onClick={() => setIslandDock(null)}>回到顶部</button>
              <button className={dock === 'left' ? 'toggle on' : 'toggle'} onClick={() => setIslandDock('left')}>停靠左侧</button>
              <button className={dock === 'right' ? 'toggle on' : 'toggle'} onClick={() => setIslandDock('right')}>停靠右侧</button>
            </div>
          </Row>
          <Row title="贴边自动收起" hint="停靠时只露出一小截把手，鼠标移上去展开。关闭后保留用量胶囊。">
            <Switch on={settings.edgeAutoHide} onChange={(edgeAutoHide) => void updateSettings({ edgeAutoHide })} />
          </Row>
          <Row title="对话结束时提示" hint="某个对话跑完一轮时，灵动岛的头像会跳一下并亮起小圆点，展开后能看到这一轮的用量小结">
            <Switch on={settings.notifyFinished} onChange={(notifyFinished) => void updateSettings({ notifyFinished })} />
          </Row>
          <Row title="开机自启" hint="登录 Windows 后自动在后台启动，只显示托盘图标和灵动岛">
            <Switch on={settings.autostart} onChange={(autostart) => void updateSettings({ autostart })} />
          </Row>
          <Row title="关闭窗口" hint="点右上角的 × 只是收到托盘，统计继续进行；要彻底退出请点这里或托盘菜单">
            <button className="btn danger" onClick={quitApp}>
              退出 Foxes Token Watch
            </button>
          </Row>
        </Card>

        <Card title="显示" className="span-6">
          <Row title="主题">
            <Segmented
              options={[
                { value: 'dark', label: '深色' },
                { value: 'light', label: '浅色' },
              ]}
              value={settings.theme}
              onChange={(theme) => void updateSettings({ theme })}
            />
          </Row>
          <Row title="数字单位" hint="1,234,567 显示成 1.23M 还是 123.5万">
            <Segmented
              options={[
                { value: 'kmb', label: 'K / M / B' },
                { value: 'wanyi', label: '万 / 亿' },
              ]}
              value={settings.units}
              onChange={(units) => void updateSettings({ units })}
            />
          </Row>
          <div className="set-note muted">
            总量 = 输入 + 缓存命中 + 缓存写入 + 输出；思考是输出的一部分。缓存命中率 = 缓存命中 ÷（输入 + 缓存命中 + 缓存写入）。Claude Code 和 Deepseek
            Harness 不单独记录思考 token，按文本占比估算，界面上标了“估算”。
          </div>
        </Card>

        <Card title="数据来源" extra={<span className="muted">自动查找当前电脑上各 agent 的数据目录；在本机读取会话用量和工具活动</span>} className="span-12">
          <div className="source-list">
            {AGENTS.map((agent, index) => {
              const live = snapshot.live.agents.find((item) => item.agent === agent)
              const roots = info?.roots[index] ?? []
              return (
                <div key={agent} className="source-row">
                  <AgentBadge agent={agent} size={28} />
                  <div className="source-main">
                    <div className="source-name">
                      {AGENT_META[agent].label}
                      {live?.detected ? <span className="tag ok">已检测到</span> : <span className="tag">未检测到</span>}
                      {live?.readError && <span className="tag bad" title={live.readError}>读取失败</span>}
                      {live?.processAlive ? <span className="tag ok">进程运行中</span> : null}
                    </div>
                    <div className="source-paths muted">
                      {roots.length > 0
                        ? roots.map((root) => (
                            <div key={root} className="ellipsis" title={root}>
                              {root}
                            </div>
                          ))
                        : '没有找到数据目录'}
                    </div>
                    {live?.readError && <div className="set-note muted" role="alert">{live.readError}，正在重试。</div>}
                  </div>
                  <div className="source-count">
                    <b className="num">{live?.files ?? 0}</b>
                    <span className="muted">个记录文件</span>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        <Card title="扫描状态" className="span-6">
          <div className="set-note muted">{scan.journalError ? '用量记录写入失败 · ' + scan.journalError : 'Kiro 和 Cursor 的用量记录保存在应用数据目录的 agent-usage.sqlite。Cursor 包含其网页 MCP 对话。'}</div>
          <div className="stat-grid">
            <div>
              <span className="muted">记录文件</span>
              <b className="num">{fmtFull(scan.files)}</b>
            </div>
            <div>
              <span className="muted">数据量</span>
              <b className="num">{fmtBytes(scan.bytes)}</b>
            </div>
            <div>
              <span className="muted">请求记录</span>
              <b className="num">{fmtFull(scan.events)}</b>
            </div>
            <div>
              <span className="muted">首次扫描</span>
              <b className="num">{fmtMs(scan.firstScanMs)}</b>
            </div>
            <div>
              <span className="muted">每秒刷新耗时</span>
              <b className="num">{fmtMs(scan.scanMs)}</b>
            </div>
            <div>
              <span className="muted">读取失败</span>
              <b className="num">{scan.failing}</b>
            </div>
          </div>
        </Card>

        <Card title="关于" className="span-6">
          <div className="about">
            <FoxLogo size={44} />
            <div className="about-text">
              <div className="about-name">
                Foxes Token Watch <span className="muted num">{info ? `v${info.version}` : ''}</span>
              </div>
              <div className="muted">作者：Foxes</div>
              <div className="muted">许可：PolyForm Noncommercial 1.0.0 · 仅限非商业用途，修改和分享时须保留 Foxes 署名及许可声明。</div>
              <div className="muted">本机 AI Agent 用量监控 · Claude Code、Codex、Deepseek Harness、Antigravity、Kiro、Cursor（含网页 MCP）。</div>
              <div className="muted">所有统计都在本机完成，软件本身不发任何网络请求。</div>
              {info?.settingsPath ? (
                <div className="muted ellipsis" title={info.settingsPath}>
                  设置保存在：{info.settingsPath}
                </div>
              ) : null}
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
