import { useState } from 'react'
import { AgentDetails } from './AgentDetails'
import { CompositionBar, Heatmap, Ring, Sparkline, StackedBars } from '../components/charts'
import type { BarColumn, Segment } from '../components/charts'
import { AgentBadge, BrandMark, Card, Empty, NetChip, PhaseChip, Segmented, Switch } from '../components/ui'
import { useNow } from '../lib/api'
import { AGENT_META, PHASE_META, compactParts, delta, fmtAgo, fmtClock, fmtDate, fmtDelta, fmtDuration, fmtFull, fmtMs, fmtPercent, fmtTime, fmtTokens, hitRate, sessionName } from '../lib/format'
import { AGENTS } from '../lib/types'
import type { Agent, DayCell, Phase, RangeId, RangeStats, RateWindow, SeriesPoint, Snapshot, Totals } from '../lib/types'

const RANGE_OPTIONS: { value: RangeId; label: string }[] = [
  { value: 'today', label: '今天' },
  { value: '7d', label: '近 7 天' },
  { value: '30d', label: '近 30 天' },
]

const RANGE_LABEL: Record<RangeId, string> = { today: '今日', '7d': '近 7 天', '30d': '近 30 天', all: '历史累计' }
const BUCKET_LABEL = { hour: '按小时', day: '按天', week: '按周' }

const PREVIOUS_LABEL: Record<RangeId, string> = { today: '较昨天同时段', '7d': '较前 7 天', '30d': '较前 30 天', all: '' }

const WEEKDAYS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']

const ESTIMATE_HINT = 'Claude Code 和 Deepseek Harness 的记录里没有单独的思考 token，这部分按思考文本在输出里的占比估算'

function tokenParts(totals: Totals | SeriesPoint): Record<'input' | 'cacheRead' | 'cacheWrite' | 'output', Segment> {
  return {
    input: { key: 'input', label: '输入', color: 'var(--c-input)', value: totals.input },
    cacheRead: { key: 'cacheRead', label: '缓存命中', color: 'var(--c-cache-read)', value: totals.cacheRead },
    cacheWrite: { key: 'cacheWrite', label: '缓存写入', color: 'var(--c-cache-write)', value: totals.cacheWrite },
    output: { key: 'output', label: '输出', color: 'var(--c-output)', value: totals.output },
  }
}

function columnText(range: RangeStats, point: SeriesPoint): { label: string; title: string } {
  const date = new Date(point.t)
  if (range.unit === 'hour') {
    return { label: `${date.getHours()}时`, title: `${fmtDate(point.t)} ${fmtTime(point.t)} – ${fmtTime(point.t + range.stepMs)}` }
  }
  const short = `${date.getMonth() + 1}/${date.getDate()}`
  if (range.unit === 'week') return { label: short, title: `${fmtDate(point.t)} 起的一周` }
  return { label: short, title: `${fmtDate(point.t)} ${WEEKDAYS[date.getDay()]}` }
}

function HeatStats({ cells }: { cells: DayCell[] }) {
  let sum = 0
  let active = 0
  let peak = 0
  let peakAt = 0
  for (const cell of cells) {
    sum += cell.total
    if (cell.total > 0) active += 1
    if (cell.total > peak) {
      peak = cell.total
      peakAt = cell.t
    }
  }
  // 从今天往回数连续有用量的天数；今天还没用不算断
  let streak = 0
  for (let index = cells.length - 1; index >= 0; index -= 1) {
    if (cells[index].total > 0) streak += 1
    else if (index !== cells.length - 1) break
  }
  return (
    <div className="heat-stats">
      <div>
        <span className="muted">合计</span>
        <b className="num" title={fmtFull(sum)}>
          {fmtTokens(sum)}
        </b>
      </div>
      <div>
        <span className="muted">有用量的天数</span>
        <b className="num">{active}</b>
      </div>
      <div>
        <span className="muted">平均每天</span>
        <b className="num">{active > 0 ? fmtTokens(sum / active) : '—'}</b>
      </div>
      <div>
        <span className="muted">最高单日{peakAt > 0 ? ` · ${fmtDate(peakAt)}` : ''}</span>
        <b className="num">{peak > 0 ? fmtTokens(peak) : '—'}</b>
      </div>
      <div>
        <span className="muted">连续使用</span>
        <b className="num">{streak} 天</b>
      </div>
    </div>
  )
}

function windowLabel(window: RateWindow): string {
  if (window.label) return window.label
  if (window.windowMinutes === 300) return '5 小时额度'
  if (window.windowMinutes === 10080) return '每周额度'
  if (window.windowMinutes % 1440 === 0) return `${window.windowMinutes / 1440} 天额度`
  return `${Math.round(window.windowMinutes / 60)} 小时额度`
}

function Kpi({ label, color, value, sub, series, tag, tagHint }: { label: string; color: string; value: number; sub: string; series: number[]; tag?: string; tagHint?: string }) {
  return (
    <div className="card kpi">
      <div className="kpi-label">
        <i style={{ background: color }} />
        {label}
        {tag ? (
          <span className="tag" title={tagHint}>
            {tag}
          </span>
        ) : null}
      </div>
      <div className="kpi-value num" title={fmtFull(value)}>
        {fmtFull(value)}
      </div>
      <div className="kpi-sub">{sub}</div>
      <Sparkline values={series} color={color} height={38} />
    </div>
  )
}

/** 额度数字最多保留两位小数：1.25 / 50 */
const fmtAmount = (value: number) => String(Number(value.toFixed(2)))

function QuotaBar({ window, now, ts }: { window: RateWindow; now: number; ts: number }) {
  const used = Math.max(0, Math.min(100, window.usedPercent))
  const tone = used >= 90 ? 'var(--down)' : used >= 70 ? 'var(--unstable)' : 'var(--ok)'
  const deadline =
    window.resetsAtMs > now
      ? `${fmtDuration(window.resetsAtMs - now)}后${window.expires ? '到期' : '重置'}`
      : window.resetsAtMs > 0
        ? window.expires
          ? '已到期'
          : '已到重置时间'
        : ''
  // 有的额度只在客户端运行时更新，读数旧了要说明是什么时候的
  const foot = [
    window.limit > 0 ? `${fmtAmount(window.used)} / ${fmtAmount(window.limit)} ${window.unit}`.trim() : '',
    deadline,
    ts > 0 && now - ts > 3_600_000 ? `${fmtAgo(ts, now)}的数据` : '',
  ].filter(Boolean)
  return (
    <div className="quota">
      <div className="quota-head">
        <span>{windowLabel(window)}</span>
        <b className="num">已用 {used.toFixed(used < 10 ? 1 : 0)}%</b>
      </div>
      <div className="quota-track">
        <i style={{ width: `${used}%`, background: tone }} />
      </div>
      <div className="quota-foot muted">{foot.join(' · ')}</div>
    </div>
  )
}

export function Overview({ snapshot }: { snapshot: Snapshot }) {
  const [rangeId, setRangeId] = useState<RangeId>('today')
  const [detail, setDetail] = useState<Agent | null>(null)
  const [mode, setMode] = useState<'type' | 'agent'>('type')
  const [hideCache, setHideCache] = useState(false)
  const now = useNow()

  const range = snapshot.ranges.find((item) => item.id === rangeId) ?? snapshot.ranges[0]
  const totals = range.totals
  const period = RANGE_LABEL[range.id]
  const elapsedSeries = range.series.filter((point) => point.t <= snapshot.generatedAt)
  const live = snapshot.live
  const parts = tokenParts(totals)
  const big = compactParts(totals.total)
  const change = delta(totals.total, range.previous?.total)
  const hit = hitRate(totals)
  const prompt = totals.input + totals.cacheRead + totals.cacheWrite
  const share = (value: number) => {
    if (totals.total <= 0) return '—'
    const ratio = value / totals.total
    return ratio > 0 && ratio < 0.001 ? '<0.1%' : fmtPercent(ratio)
  }

  const columns: BarColumn[] = elapsedSeries.map((point) => {
    const text = columnText(range, point)
    const byType = tokenParts(point)
    const segments =
      mode === 'type'
        ? [byType.cacheRead, byType.cacheWrite, byType.input, byType.output].filter((segment) => !(hideCache && segment.key === 'cacheRead'))
        : AGENTS.map((agent, index) => ({ key: agent, label: AGENT_META[agent].short, color: AGENT_META[agent].color, value: point.byAgent[index] }))
    return { t: point.t, label: text.label, title: text.title, segments, note: `${point.requests} 次请求` }
  })

  const rateTotals = live.rate.map((point) => point.input + point.cacheRead + point.cacheWrite + point.output)
  const lastHour = rateTotals.reduce((sum, value) => sum + value, 0)
  const recentRate = rateTotals.slice(-5).reduce((sum, value) => sum + value, 0) / 5
  const phases = (Object.keys(live.phases) as (keyof typeof live.phases)[]).filter((phase) => live.phases[phase] > 0)
  const running = live.sessions.filter((session) => session.running)
  const recent = live.sessions.filter((session) => !session.running).slice(0, Math.max(0, 6 - running.length))
  const topModels = range.byModel.slice(0, 5)
  const topModelTotal = Math.max(1, ...topModels.map((model) => model.totals.total))
  const estimated = totals.reasoningEstimated > 0
  const rangeControls = (
        <div className="range-controls">
          {rangeId !== 'all' && <Segmented options={RANGE_OPTIONS} value={rangeId} onChange={setRangeId} />}
          <label className="history-toggle">
            历史总用量
            <Switch on={rangeId === 'all'} onChange={(on) => setRangeId(on ? 'all' : 'today')} />
          </label>
        </div>
  )
  if (detail) return <AgentDetails agent={detail} snapshot={snapshot} range={range} period={period} controls={rangeControls} back={() => setDetail(null)} />

  return (
    <div className="page">
      <header className="page-head brand-head">
        <BrandMark>
          <h1>总览</h1>
          <span className="muted">
            {fmtDate(range.from)}
            {range.id === 'today' ? '' : ` – ${fmtDate(range.to)}`} · 数据更新于 {fmtTime(snapshot.generatedAt, true)}
          </span>
        </BrandMark>
        {rangeControls}
      </header>

      <div className="grid">
        <Card className="span-8 hero">
          <div className="hero-top">
            <div className="hero-main">
              <div className="hero-label">{period} Token 用量 {totals.estimated > 0 && <span className="tag" title={fmtFull(totals.estimated) + ' token 为估算值'}>含估算</span>}</div>
              <div className="hero-value num">
                {big.value}
                <small>{big.unit}</small>
              </div>
              <div className="hero-sub">
                <span className="num">{fmtFull(totals.total)}</span> tokens
                <i />
                <span className="num">{fmtFull(totals.requests)}</span> 次请求
                <i />
                <span className="num">{range.sessions}</span> 个对话
                {change !== null ? (
                  <span className={change >= 0 ? 'delta up' : 'delta down'} title={`上一时段 ${fmtFull(range.previous?.total ?? 0)}`}>
                    {fmtDelta(change)} {PREVIOUS_LABEL[range.id]}
                  </span>
                ) : null}
              </div>
            </div>
            <Ring value={hit} size={92} stroke={9} color="var(--c-cache-read)">
              <b className="num">{prompt > 0 ? fmtPercent(hit, hit >= 0.9995 ? 0 : 1) : '—'}</b>
              <span>缓存命中率</span>
            </Ring>
          </div>
          <CompositionBar parts={[parts.input, parts.cacheRead, parts.cacheWrite, parts.output]} height={14} />
          <div className="legend">
            {[parts.input, parts.cacheRead, parts.cacheWrite, parts.output].map((part) => (
              <div key={part.key} className="legend-item">
                <i style={{ background: part.color }} />
                <span>{part.label}</span>
                <b className="num" title={fmtFull(part.value)}>
                  {fmtTokens(part.value)}
                </b>
                <em className="num">{share(part.value)}</em>
              </div>
            ))}
          </div>
        </Card>

        <Card className="span-4 live-card" title="实时" extra={<NetChip status={live.net.status} />}>
          <div className="live-count">
            <b className={live.running > 0 ? 'num on' : 'num'}>{live.running}</b>
            <div>
              <div>个对话正在运行</div>
              <div className="muted">{live.runningSubAgents > 0 ? `另有 ${live.runningSubAgents} 个子代理在跑` : live.running > 0 ? '没有子代理在跑' : '所有 agent 都空闲'}</div>
            </div>
          </div>
          <div className="phase-row">
            {phases.length === 0 ? <span className="muted">有对话开始运行时，这里会显示每个对话正在做什么</span> : null}
            {phases.map((phase) => (
              <span key={phase} className={`chip tone-${PHASE_META[phase as Phase].tone}`}>
                <span className="dot pulse" />
                {PHASE_META[phase as Phase].label}
                <b className="num">{live.phases[phase]}</b>
              </span>
            ))}
          </div>
          <div className="live-rate">
            <Sparkline values={rateTotals} color="var(--accent)" height={46} />
            <div className="live-rate-meta">
              <div>
                <span className="muted">近 1 小时</span>
                <b className="num">{fmtTokens(lastHour)}</b>
              </div>
              <div>
                <span className="muted">速率</span>
                <b className="num">{fmtTokens(recentRate)}/分</b>
              </div>
            </div>
          </div>
        </Card>

        <section className="span-12 kpi-section" aria-label={period + '用量明细'}>
          <header className="kpi-caption"><strong>{period}用量明细</strong><span>折线{BUCKET_LABEL[range.unit]}统计</span></header>
          <div className="kpi-row">
            <Kpi label="输入" color="var(--c-input)" value={totals.input} sub={`占输入侧 ${prompt > 0 ? fmtPercent(totals.input / prompt) : '—'}`} series={elapsedSeries.map((point) => point.input)} />
            <Kpi label="缓存命中" color="var(--c-cache-read)" value={totals.cacheRead} sub={`命中率 ${prompt > 0 ? fmtPercent(hit) : '—'}`} series={elapsedSeries.map((point) => point.cacheRead)} />
            <Kpi label="缓存写入" color="var(--c-cache-write)" value={totals.cacheWrite} sub={`占输入侧 ${prompt > 0 ? fmtPercent(totals.cacheWrite / prompt) : '—'}`} series={elapsedSeries.map((point) => point.cacheWrite)} />
            <Kpi label="输出" color="var(--c-output)" value={totals.output} sub={`平均每次 ${totals.requests > 0 ? fmtTokens(totals.output / totals.requests) : '—'}`} series={elapsedSeries.map((point) => point.output)} />
            <Kpi
              label="思考"
              color="var(--c-think)"
              value={totals.reasoning}
              sub={`占输出 ${totals.output > 0 ? fmtPercent(totals.reasoning / totals.output) : '—'}${totals.thinkMs > 0 ? ` · ${fmtDuration(totals.thinkMs)}` : ''}`}
              series={elapsedSeries.map((point) => point.reasoning)}
              tag={estimated ? '含估算' : undefined}
              tagHint={ESTIMATE_HINT}
            />
            <Kpi label="请求数" color="var(--text-2)" value={totals.requests} sub={`平均每次 ${totals.requests > 0 ? fmtTokens(totals.total / totals.requests) : '—'}`} series={elapsedSeries.map((point) => point.requests)} />
          </div>
        </section>

        <Card
          className="span-8"
          title="用量趋势"
          extra={
            <div className="card-tools">
              {mode === 'type' ? (
                <button className={hideCache ? 'toggle on' : 'toggle'} onClick={() => setHideCache(!hideCache)} title="缓存命中通常占绝大部分，隐藏后能看清其余几项">
                  隐藏缓存命中
                </button>
              ) : null}
              <Segmented
                options={[
                  { value: 'type', label: '按类型' },
                  { value: 'agent', label: '按 Agent' },
                ]}
                value={mode}
                onChange={setMode}
              />
            </div>
          }
        >
          <StackedBars columns={columns} height={236} />
          <div className="chart-legend">
            {(columns[0]?.segments ?? []).map((segment) => (
              <span key={segment.key}>
                <i style={{ background: segment.color }} />
                {segment.label}
              </span>
            ))}
          </div>
        </Card>

        <Card className="span-4" title="各 Agent">
          <div className="agent-list">
            {AGENTS.map((agent) => {
              const stats = range.byAgent.find((item) => item.agent === agent)
              const state = live.agents.find((item) => item.agent === agent)
              const total = stats?.totals.total ?? 0
              const status = !state?.detected ? '本机未发现' : state.running > 0 ? '' : state.processAlive === false ? '未启动' : state.lastActive > 0 ? `${fmtAgo(state.lastActive, now)}活动` : '空闲'
              return (
                <details key={agent} className="agent-disclosure">
                  <summary className={state?.detected ? 'agent-row' : 'agent-row off'}>
                  <AgentBadge agent={agent} size={32} />
                  <div className="agent-main">
                    <div className="agent-name">
                      <span className="ellipsis">{AGENT_META[agent].label}</span>
                      {(stats?.totals.estimated ?? 0) > 0 && <span className="tag">估算</span>}
                      {state && state.running > 0 ? (
                        <span className="chip tone-ok">
                          <span className="dot pulse" />
                          运行中 {state.running}
                        </span>
                      ) : null}
                    </div>
                    <div className="agent-bar">
                      <i style={{ width: `${totals.total > 0 ? (total / totals.total) * 100 : 0}%`, background: AGENT_META[agent].color }} />
                    </div>
                    <div className="agent-meta muted ellipsis">
                      {stats && stats.sessions > 0 ? `${stats.sessions} 个对话 · 命中率 ${fmtPercent(hitRate(stats.totals), 0)}` : '这段时间没有用量'}
                      {status ? ` · ${status}` : ''}
                    </div>
                  </div>
                  <div className="agent-total">
                    <b className="num" title={fmtFull(total)}>
                      {fmtTokens(total)}
                    </b>
                    <span className="num muted">{share(total)}</span>
                  </div>
                  <span className="disclosure-arrow" aria-hidden="true">⌄</span>
                  </summary>
                  <div className="agent-expanded">
                    <span>输入 {fmtTokens(stats?.totals.input ?? 0)} · 输出 {fmtTokens(stats?.totals.output ?? 0)}</span>
                    <span>{fmtFull(stats?.totals.requests ?? 0)} 次请求 · {stats?.sessions ?? 0} 个对话</span>
                    <button className="btn" onClick={() => setDetail(agent)}>查看{AGENT_META[agent].short}详情 →</button>
                  </div>
                </details>
              )
            })}
          </div>
        </Card>

        <Card className="span-7" title="对话" extra={<span className="muted">{running.length > 0 ? `${running.length} 个运行中` : '最近活动'}</span>}>
          {running.length + recent.length === 0 ? <Empty>最近 30 分钟没有对话活动</Empty> : null}
          <div className="sess-list">
            {[...running, ...recent].map((session) => (
              <div key={session.key} className={session.running ? 'sess-row running' : 'sess-row'}>
                <AgentBadge agent={session.agent} size={28} />
                <div className="sess-main">
                  <div className="sess-title ellipsis">{sessionName(session)}</div>
                  <div className="sess-meta muted ellipsis">
                    {[session.project, session.model, session.turns > 0 ? `${session.turns} 轮` : '', session.subAgents > 0 ? `${session.subAgents} 个子代理${session.runningSubAgents > 0 ? `（${session.runningSubAgents} 个在跑）` : ''}` : ''].filter(Boolean).join(' · ')}
                  </div>
                </div>
                {session.running ? <PhaseChip phase={session.phase} tool={session.tool} /> : <span className="muted sess-ago">{fmtAgo(session.lastActive, now)}</span>}
                <div className="sess-clock num" title="这一步已持续 / 本轮已持续">
                  {session.running ? (
                    <>
                      {fmtClock(now - session.phaseSince)}
                      <span className="muted">{session.turnStarted > 0 ? fmtClock(now - session.turnStarted) : ''}</span>
                    </>
                  ) : null}
                </div>
                <div className="sess-tokens">
                  <b className="num">{fmtTokens(session.running ? session.turn.total : session.totals.total)}</b>
                  <span className="muted">{session.running ? '本轮' : '累计'}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="span-5" title="网络状况" extra={<span className="muted">最近 15 分钟</span>}>
          <div className="net-list">
            {live.agents
              .filter((agent) => agent.detected)
              .map((agent) => (
                <div key={agent.agent} className="net-row">
                  <AgentBadge agent={agent.agent} size={24} />
                  <span className="net-name ellipsis">{AGENT_META[agent.agent].short}</span>
                  <NetChip status={agent.net.status} />
                  <span className="net-figure num" title="首字延迟（中位数）">
                    <em>首字</em>
                    {fmtMs(agent.net.ttftMs)}
                  </span>
                  <span className="net-figure num" title="整次响应耗时（中位数）">
                    <em>响应</em>
                    {fmtMs(agent.net.latencyMs)}
                  </span>
                  <span className={agent.net.retries + agent.net.errors > 0 ? 'net-issues num warn' : 'net-issues num'} title="重试 / 报错次数">
                    {agent.net.retries + agent.net.errors > 0 ? `${agent.net.retries + agent.net.errors} 次异常` : '无异常'}
                  </span>
                </div>
              ))}
          </div>
          <div className="net-events">
            {live.netEvents.length === 0 ? <div className="muted">最近 24 小时没有重试或报错</div> : null}
            {live.netEvents.slice(0, 3).map((event, index) => (
              <div key={`${event.ts}-${index}`} className="net-event">
                <span className="num muted">{now - event.ts < 86_400_000 ? fmtTime(event.ts) : fmtDate(event.ts)}</span>
                <span>{AGENT_META[event.agent].short}</span>
                <span className={event.kind === 'error' ? 'tag bad' : 'tag'}>{event.code || (event.kind === 'error' ? '报错' : '重试')}</span>
                <span className="muted ellipsis">{event.kind === 'retry' ? `第 ${event.attempt}${event.maxAttempts > 0 ? `/${event.maxAttempts}` : ''} 次重试` : '请求失败'}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="span-7" title="近 26 周" extra={<span className="muted">每格一天，颜色越深用量越大</span>}>
          <div className="heatmap-wrap">
            <Heatmap cells={snapshot.heatmap} />
          </div>
          <HeatStats cells={snapshot.heatmap} />
        </Card>

        <Card className="span-5" title={live.rateLimits.length > 0 ? '额度与模型' : '模型排行'}>
          {live.rateLimits.map((limit) => (
            <div key={limit.agent} className="quota-block">
              <div className="quota-title">
                <AgentBadge agent={limit.agent} size={20} />
                <span>{AGENT_META[limit.agent].short} 额度</span>
                {limit.plan ? <span className="tag">{limit.plan}</span> : null}
              </div>
              {limit.primary ? <QuotaBar window={limit.primary} now={now} ts={limit.ts} /> : null}
              {limit.secondary ? <QuotaBar window={limit.secondary} now={now} ts={limit.ts} /> : null}
            </div>
          ))}
          <div className="model-list">
            {topModels.length === 0 ? <Empty>这段时间没有用量</Empty> : null}
            {topModels.map((model) => (
              <div key={`${model.agent}/${model.model}`} className="model-row">
                <AgentBadge agent={model.agent} size={20} />
                <span className="model-name ellipsis" title={model.model}>
                  {model.model || '未知模型'}
                </span>
                <div className="model-bar">
                  <i style={{ width: `${(model.totals.total / topModelTotal) * 100}%`, background: AGENT_META[model.agent].color }} />
                </div>
                <b className="num">{fmtTokens(model.totals.total)}</b>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
