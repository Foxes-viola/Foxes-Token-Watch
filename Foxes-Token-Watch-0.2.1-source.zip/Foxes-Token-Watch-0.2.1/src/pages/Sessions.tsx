import { useEffect, useMemo, useRef, useState } from 'react'
import { AgentBadge, Empty, Icon, PhaseChip, Segmented } from '../components/ui'
import { fetchSessions, useNow } from '../lib/api'
import { AGENT_META, fmtAgo, fmtFull, fmtPercent, fmtTokens, hitRate, sessionName } from '../lib/format'
import { AGENTS } from '../lib/types'
import type { Agent, SessionView, Snapshot } from '../lib/types'

type Filter = 'all' | Agent
type Sort = 'recent' | 'total'

const FILTERS: { value: Filter; label: string }[] = [{ value: 'all', label: '全部' }, ...AGENTS.map((agent) => ({ value: agent as Filter, label: AGENT_META[agent].short }))]

const MAX_ROWS = 300

export function Sessions({ snapshot }: { snapshot: Snapshot }) {
  const [sessions, setSessions] = useState<SessionView[] | null>(null)
  const [filter, setFilter] = useState<Filter>('all')
  const [sort, setSort] = useState<Sort>('recent')
  const [query, setQuery] = useState('')
  const [showSubAgents, setShowSubAgents] = useState(false)
  const now = useNow(5000)
  const lastFetch = useRef(0)
  const requestId = useRef(0)

  // 快照每变一次就重新取一次列表，但最多每 2 秒一次
  useEffect(() => {
    const wait = Math.max(0, 2000 - (Date.now() - lastFetch.current))
    const timer = window.setTimeout(() => {
      lastFetch.current = Date.now()
      const id = ++requestId.current
      void fetchSessions().then((rows) => {
        if (id === requestId.current) setSessions(rows)
      })
    }, wait)
    return () => window.clearTimeout(timer)
  }, [snapshot.generatedAt])

  const rows = useMemo(() => {
    const needle = query.trim().toLowerCase()
    const list = (sessions ?? []).filter((session) => {
      if (filter !== 'all' && session.agent !== filter) return false
      if (session.subAgent && !showSubAgents) return false
      if (!needle) return true
      return [session.title, session.project, session.model, session.cwd].some((text) => text.toLowerCase().includes(needle))
    })
    if (sort === 'total') list.sort((a, b) => b.totals.total - a.totals.total)
    else list.sort((a, b) => Number(b.running) - Number(a.running) || b.lastActive - a.lastActive)
    return list
  }, [sessions, filter, sort, query, showSubAgents])

  const subAgentCount = (sessions ?? []).filter((session) => session.subAgent).length

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>对话</h1>
          <p className="muted">
            共 {sessions ? sessions.length - subAgentCount : '…'} 个对话
            {subAgentCount > 0 ? `，另有 ${subAgentCount} 个子代理记录` : ''} · {snapshot.live.running} 个正在运行
          </p>
        </div>
        <div className="card-tools">
          <label className="search">
            <Icon name="search" size={15} />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索标题、项目、模型" spellCheck={false} />
          </label>
          {subAgentCount > 0 ? (
            <button className={showSubAgents ? 'toggle on' : 'toggle'} onClick={() => setShowSubAgents(!showSubAgents)}>
              显示子代理
            </button>
          ) : null}
          <Segmented
            options={[
              { value: 'recent', label: '最近活动' },
              { value: 'total', label: '用量最多' },
            ]}
            value={sort}
            onChange={setSort}
          />
        </div>
      </header>

      <div className="filter-row">
        <Segmented options={FILTERS} value={filter} onChange={setFilter} />
      </div>

      <div className="card table-card">
        <div className="table sess-table">
          <div className="tr th">
            <span>对话</span>
            <span>状态</span>
            <span className="r">轮数</span>
            <span className="r">输入</span>
            <span className="r">缓存命中</span>
            <span className="r">缓存写入</span>
            <span className="r">输出</span>
            <span className="r">命中率</span>
            <span className="r">总量</span>
          </div>
          {sessions === null ? <Empty>正在读取…</Empty> : null}
          {sessions !== null && rows.length === 0 ? <Empty>没有符合条件的对话</Empty> : null}
          {rows.slice(0, MAX_ROWS).map((session) => (
            <div key={session.key} className={session.running ? 'tr running' : 'tr'}>
              <span className="sess-cell">
                <AgentBadge agent={session.agent} size={26} />
                <span className="sess-main">
                  <span className="sess-title ellipsis">
                    {sessionName(session)}
                    {session.subAgent ? <span className="tag">子代理</span> : null}
                    {session.sourceGone ? (
                      <span className="tag" title="原始记录已被删除，数字来自此前的统计">
                        记录已删
                      </span>
                    ) : null}
                  </span>
                  <span className="sess-meta muted ellipsis" title={session.cwd}>
                    {[session.project, session.model, session.subAgents > 0 ? `${session.subAgents} 个子代理` : ''].filter(Boolean).join(' · ') || '—'}
                  </span>
                </span>
              </span>
              <span>{session.running ? <PhaseChip phase={session.phase} tool={session.tool} /> : <span className="muted">{fmtAgo(session.lastActive, now)}</span>}</span>
              <span className="r num">{session.turns || '—'}</span>
              <span className="r num">{fmtTokens(session.totals.input)}</span>
              <span className="r num">{fmtTokens(session.totals.cacheRead)}</span>
              <span className="r num">{session.totals.cacheWrite > 0 ? fmtTokens(session.totals.cacheWrite) : '—'}</span>
              <span className="r num">{fmtTokens(session.totals.output)}</span>
              <span className="r num">{session.totals.total > 0 ? fmtPercent(hitRate(session.totals), 0) : '—'}</span>
              <span className="r num strong" title={fmtFull(session.totals.total)}>
                {fmtTokens(session.totals.total)}
              </span>
            </div>
          ))}
          {rows.length > MAX_ROWS ? <div className="muted table-more">只显示前 {MAX_ROWS} 条，共 {rows.length} 条</div> : null}
        </div>
      </div>
    </div>
  )
}
