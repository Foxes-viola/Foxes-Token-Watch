import { useId } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import { AGENT_META, NET_META, PHASE_META } from '../lib/format'
import type { Agent, NetStatus, Phase } from '../lib/types'

const ICONS = {
  overview: (
    <>
      <rect x="3.5" y="3.5" width="7" height="7" rx="2" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="2" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="2" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="2" />
    </>
  ),
  sessions: (
    <>
      <path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v7a2.5 2.5 0 0 1-2.5 2.5H11l-4.5 3.5V16A2.5 2.5 0 0 1 4 13.5z" />
      <path d="M8.5 9h7M8.5 12h4.5" />
    </>
  ),
  models: (
    <>
      <path d="M12 3.5 20 8l-8 4.5L4 8z" />
      <path d="m4 12 8 4.5 8-4.5" />
      <path d="m4 16 8 4.5 8-4.5" />
    </>
  ),
  network: <path d="M3 12h4l2.5-6 4 12 2.5-6H21" />,
  settings: (
    <>
      <path d="M4 7h9M17 7h3M4 17h3M11 17h9" />
      <circle cx="15" cy="7" r="2" />
      <circle cx="9" cy="17" r="2" />
    </>
  ),
  minimize: <path d="M6 12h12" />,
  maximize: <rect x="6.5" y="6.5" width="11" height="11" rx="1.5" />,
  close: <path d="m7 7 10 10M17 7 7 17" />,
  panel: (
    <>
      <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
      <path d="M3.5 9h17" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="6" />
      <path d="m16 16 4 4" />
    </>
  ),
  bolt: <path d="M13 3 5 13.5h6L10 21l8-10.5h-6z" />,
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
} satisfies Record<string, ReactNode>

export type IconName = keyof typeof ICONS

export function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      {ICONS[name]}
    </svg>
  )
}

/** 狐狸头标志（不带底板），和 design/icon.svg 是同一个图形 */
export function FoxLogo({ size = 20 }: { size?: number }) {
  // 同一页面上可能有多个标志，渐变 id 必须各不相同，否则隐藏的那个会让其余的丢色
  const fur = `fox-fur-${useId().replace(/[^\w-]/g, '')}`
  return (
    <svg width={size} height={size} viewBox="64 66 384 384" aria-hidden>
      <defs>
        <linearGradient id={fur} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#cdb0ff" />
          <stop offset="1" stopColor="#7a48f2" />
        </linearGradient>
      </defs>
      <g strokeLinejoin="round" strokeWidth="14">
        <path d="M112 86 L226 184 L122 266 Z" fill="#8f62f5" stroke="#8f62f5" />
        <path d="M400 86 L286 184 L390 266 Z" fill="#8f62f5" stroke="#8f62f5" />
        <path d="M256 172 L398 238 L428 280 L256 434 L84 280 L114 238 Z" fill={`url(#${fur})`} stroke={`url(#${fur})`} />
        <path d="M84 280 L206 304 L256 434 Z" fill="#f5eeff" stroke="#f5eeff" />
        <path d="M428 280 L306 304 L256 434 Z" fill="#f5eeff" stroke="#f5eeff" />
      </g>
      <ellipse cx="190" cy="266" rx="17" ry="15" fill="#1a1230" />
      <ellipse cx="322" cy="266" rx="17" ry="15" fill="#1a1230" />
      <path d="M232 400 L280 400 L256 432 Z" fill="#1a1230" stroke="#1a1230" strokeWidth="12" strokeLinejoin="round" />
    </svg>
  )
}

/** 主页顶部的品牌区：带光晕的狐狸标志 + 艺术字 */
export function BrandMark({ children }: { children?: ReactNode }) {
  return (
    <div className="brandmark">
      <div className="brandmark-logo">
        <FoxLogo size={46} />
      </div>
      <div className="brandmark-text">
        <div className="wordmark" aria-label="Foxes Token Watch">
          <span className="wordmark-fox">FOXES</span>
          <span className="wordmark-rest">Token Watch</span>
        </div>
        {children ? <div className="brandmark-sub">{children}</div> : null}
      </div>
    </div>
  )
}

const BADGE_TEXT: Record<Agent, string> = { claude: 'Cl', codex: 'Cx', deepseek: 'Ds', antigravity: 'Ag', kiro: 'Ki', cursor: 'Cu', webmcp: 'W' }

export function AgentBadge({ agent, size = 22 }: { agent: Agent; size?: number }) {
  const style = { width: size, height: size, fontSize: Math.round(size * 0.46), '--badge-color': AGENT_META[agent].color } as CSSProperties
  return (
    <span className="agent-badge" style={style} title={AGENT_META[agent].label}>
      {BADGE_TEXT[agent]}
    </span>
  )
}

export function PhaseChip({ phase, tool }: { phase: Phase; tool?: string }) {
  const meta = PHASE_META[phase]
  return (
    <span className={`chip tone-${meta.tone}`}>
      <span className={phase === 'idle' ? 'dot' : 'dot pulse'} />
      {meta.label}
      {phase === 'tool' && tool ? <span className="chip-extra">{tool}</span> : null}
    </span>
  )
}

export function NetChip({ status }: { status: NetStatus }) {
  const meta = NET_META[status]
  return (
    <span className={`chip tone-${meta.tone}`} title={meta.hint}>
      <span className={status === 'unstable' || status === 'down' ? 'dot pulse' : 'dot'} />
      {meta.label}
    </span>
  )
}

export function Segmented<T extends string>({ options, value, onChange }: { options: { value: T; label: string }[]; value: T; onChange: (value: T) => void }) {
  return (
    <div className="segmented" role="tablist">
      {options.map((option) => (
        <button key={option.value} role="tab" aria-selected={option.value === value} className={option.value === value ? 'active' : ''} onClick={() => onChange(option.value)}>
          {option.label}
        </button>
      ))}
    </div>
  )
}

export function Switch({ on, onChange }: { on: boolean; onChange: (on: boolean) => void }) {
  return <button className={on ? 'switch on' : 'switch'} role="switch" aria-checked={on} onClick={() => onChange(!on)} />
}

export function Card({ title, extra, className = '', children }: { title?: ReactNode; extra?: ReactNode; className?: string; children: ReactNode }) {
  return (
    <section className={`card ${className}`}>
      {title || extra ? (
        <header className="card-head">
          <span className="card-title">{title}</span>
          {extra}
        </header>
      ) : null}
      {children}
    </section>
  )
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="empty">{children}</div>
}
