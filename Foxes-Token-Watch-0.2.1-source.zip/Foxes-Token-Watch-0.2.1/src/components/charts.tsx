import { useId, useState } from 'react'
import type { ReactNode } from 'react'
import { fmtDate, fmtFull, fmtTokens } from '../lib/format'
import type { DayCell } from '../lib/types'

export interface Segment {
  key: string
  label: string
  color: string
  value: number
}

export function Sparkline({ values, color, height = 36, fill = true }: { values: number[]; color: string; height?: number; fill?: boolean }) {
  const id = useId().replace(/:/g, '')
  const width = 100
  if (values.length < 2) return <svg className="sparkline" height={height} />
  const max = Math.max(...values, 1)
  const step = width / (values.length - 1)
  const line = values.map((value, index) => `${index ? 'L' : 'M'}${(index * step).toFixed(2)} ${(height - 2 - (value / max) * (height - 5)).toFixed(2)}`).join(' ')
  return (
    <svg className="sparkline" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" height={height}>
      {fill ? (
        <>
          <defs>
            <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={color} stopOpacity="0.32" />
              <stop offset="1" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={`${line} L${width} ${height} L0 ${height} Z`} fill={`url(#${id})`} />
        </>
      ) : null}
      <path d={line} fill="none" stroke={color} strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
    </svg>
  )
}

/** 横向的构成条：各段宽度按数值占比 */
export function CompositionBar({ parts, height = 12 }: { parts: Segment[]; height?: number }) {
  return (
    <div className="compbar" style={{ height }}>
      {parts.map((part) => (part.value > 0 ? <i key={part.key} style={{ flexGrow: part.value, background: part.color }} title={`${part.label} ${fmtFull(part.value)}`} /> : null))}
    </div>
  )
}

export function Ring({ value, size = 84, stroke = 8, color, children }: { value: number; size?: number; stroke?: number; color: string; children?: ReactNode }) {
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const clamped = Math.max(0, Math.min(1, value))
  const center = size / 2
  return (
    <div className="ring" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={center} cy={center} r={radius} fill="none" stroke="var(--line-strong)" strokeWidth={stroke} />
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={`${circumference * clamped} ${circumference}`}
          transform={`rotate(-90 ${center} ${center})`}
        />
      </svg>
      <div className="ring-label">{children}</div>
    </div>
  )
}

export interface BarColumn {
  t: number
  /** 横轴上的短标签 */
  label: string
  /** 悬停提示的标题 */
  title: string
  segments: Segment[]
  note?: string
}

function niceMax(value: number): number {
  if (value <= 0) return 1
  const exponent = Math.pow(10, Math.floor(Math.log10(value)))
  const fraction = value / exponent
  const nice = fraction <= 1 ? 1 : fraction <= 2 ? 2 : fraction <= 2.5 ? 2.5 : fraction <= 5 ? 5 : 10
  return nice * exponent
}

/** 堆叠柱状图：每根柱子自下而上按 segments 的顺序堆叠 */
export function StackedBars({ columns, height = 220 }: { columns: BarColumn[]; height?: number }) {
  const [hover, setHover] = useState<number | null>(null)
  const sums = columns.map((column) => column.segments.reduce((sum, segment) => sum + segment.value, 0))
  const max = niceMax(Math.max(...sums, 0))
  const ticks = [1, 0.75, 0.5, 0.25]
  const labelEvery = Math.max(1, Math.ceil(columns.length / 9))
  const active = hover !== null && hover < columns.length ? columns[hover] : null
  const activeSum = hover !== null && hover < columns.length ? sums[hover] : 0
  const tipSide = hover !== null && hover / Math.max(1, columns.length) > 0.6 ? 'left' : 'right'

  return (
    <div className="trend" style={{ height }}>
      <div className="trend-y">
        {ticks.map((tick) => (
          <span key={tick} style={{ bottom: `${tick * 100}%` }} className="num">
            {fmtTokens(max * tick)}
          </span>
        ))}
      </div>
      <div className="trend-main">
        <div className="trend-plot" onMouseLeave={() => setHover(null)}>
          {ticks.map((tick) => (
            <i key={tick} className="trend-grid" style={{ bottom: `${tick * 100}%` }} />
          ))}
          <div className="trend-bars">
            {columns.map((column, index) => (
              <div key={column.t} className={index === hover ? 'trend-col hover' : 'trend-col'} onMouseEnter={() => setHover(index)}>
                <div className="trend-bar" style={{ height: `${(sums[index] / max) * 100}%`, minHeight: sums[index] > 0 ? 2 : 0 }}>
                  {column.segments.map((segment) => (segment.value > 0 ? <i key={segment.key} style={{ flexGrow: segment.value, background: segment.color }} /> : null))}
                </div>
              </div>
            ))}
          </div>
          {active ? (
            <div className={`trend-tip ${tipSide}`} style={tipSide === 'right' ? { left: `${(((hover ?? 0) + 1) / columns.length) * 100}%` } : { right: `${(1 - (hover ?? 0) / columns.length) * 100}%` }}>
              <div className="trend-tip-title">{active.title}</div>
              {active.segments.map((segment) => (
                <div key={segment.key} className="trend-tip-row">
                  <i style={{ background: segment.color }} />
                  <span>{segment.label}</span>
                  <b className="num">{fmtTokens(segment.value)}</b>
                </div>
              ))}
              <div className="trend-tip-row total">
                <span>合计</span>
                <b className="num">{fmtTokens(activeSum)}</b>
              </div>
              {active.note ? <div className="trend-tip-note">{active.note}</div> : null}
            </div>
          ) : null}
        </div>
        <div className="trend-x">
          {columns.map((column, index) => (
            <span key={column.t}>{index % labelEvery === 0 ? column.label : ''}</span>
          ))}
        </div>
      </div>
    </div>
  )
}

const CELL = 15

/** 最近 26 周每天的用量，每列一周（周一在上） */
export function Heatmap({ cells }: { cells: DayCell[] }) {
  if (cells.length === 0) return null
  const max = Math.max(...cells.map((cell) => cell.total), 1)
  const offset = (new Date(cells[0].t).getDay() + 6) % 7
  const months: { column: number; label: string }[] = []
  cells.forEach((cell, index) => {
    const date = new Date(cell.t)
    if (date.getDate() === 1) months.push({ column: Math.floor((index + offset) / 7), label: `${date.getMonth() + 1}月` })
  })
  const columns = Math.ceil((cells.length + offset) / 7)
  return (
    <div className="heatmap" style={{ width: columns * CELL }}>
      <div className="heatmap-months">
        {months.map((month) => (
          <span key={month.column} style={{ left: month.column * CELL }}>
            {month.label}
          </span>
        ))}
      </div>
      <div className="heatmap-grid">
        {Array.from({ length: offset }, (_, index) => (
          <i key={`pad-${index}`} className="heat-pad" />
        ))}
        {cells.map((cell) => {
          const level = cell.total <= 0 ? 0 : 1 + Math.min(3, Math.floor(Math.sqrt(cell.total / max) * 4))
          return <i key={cell.t} className={`heat-cell l${level}`} title={`${fmtDate(cell.t)} · ${fmtTokens(cell.total)} · ${cell.requests} 次请求`} />
        })}
      </div>
    </div>
  )
}
