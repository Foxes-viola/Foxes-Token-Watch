// 与 crates/foxes-core/src/aggregate.rs 里的序列化结构一一对应。

export type Agent = 'claude' | 'codex' | 'deepseek' | 'antigravity' | 'kiro' | 'cursor' | 'webmcp'

/** 保持后台 Agent::ALL 的索引；Cursor 内的网页 MCP 一并归入 Cursor。 */
export const AGENTS: Agent[] = ['claude', 'codex', 'deepseek', 'antigravity', 'kiro', 'cursor']

export type Phase = 'idle' | 'requesting' | 'thinking' | 'writing' | 'generating' | 'tool' | 'retrying' | 'waiting'

export type NetStatus = 'idle' | 'ok' | 'slow' | 'unstable' | 'down'

export type RangeId = 'today' | '7d' | '30d' | 'all'

export interface Totals {
  input: number
  cacheRead: number
  cacheWrite: number
  output: number
  /** 思考 token，是 output 的一部分 */
  reasoning: number
  /** reasoning 里估算出来的部分 */
  reasoningEstimated: number
  total: number
  /** total 里整条估算的部分（Kiro / Cursor / 网页 MCP 的记录里没有 token 数） */
  estimated: number
  /** 消耗的计费额度（目前只有 Kiro 记录 credits） */
  credits: number
  requests: number
  thinkMs: number
}

export interface SeriesPoint {
  t: number
  input: number
  cacheRead: number
  cacheWrite: number
  output: number
  reasoning: number
  requests: number
  /** 各 agent 的总量，顺序同 AGENTS */
  byAgent: number[]
}

export interface AgentTotals {
  agent: Agent
  totals: Totals
  sessions: number
}

export interface ModelTotals {
  agent: Agent
  model: string
  totals: Totals
}

export interface ProjectTotals {
  project: string
  cwd: string
  totals: Totals
  sessions: number
  agents: Agent[]
}

export interface RangeStats {
  id: RangeId
  from: number
  to: number
  totals: Totals
  previous: Totals | null
  sessions: number
  byAgent: AgentTotals[]
  byModel: ModelTotals[]
  byProject: ProjectTotals[]
  unit: 'hour' | 'day' | 'week'
  stepMs: number
  series: SeriesPoint[]
}

export interface SessionView {
  key: string
  agent: Agent
  id: string
  title: string
  project: string
  cwd: string
  model: string
  running: boolean
  subAgent: boolean
  phase: Phase
  phaseSince: number
  tool: string
  turnStarted: number
  started: number
  lastActive: number
  totals: Totals
  turn: Totals
  contextUsed: number
  contextWindow: number
  turns: number
  subAgents: number
  runningSubAgents: number
  sourceGone: boolean
}

export interface NetStats {
  status: NetStatus
  latencyMs: number
  ttftMs: number
  samples: number
  requests: number
  retries: number
  errors: number
  lastOk: number
  lastIssue: number
  lastCode: string
}

export interface NetEventView {
  ts: number
  agent: Agent
  kind: 'retry' | 'error'
  code: string
  attempt: number
  maxAttempts: number
  delayMs: number
  project: string
}

export interface LatencyPoint {
  t: number
  agent: Agent
  latencyMs: number
  ttftMs: number
}

export interface AgentLive {
  agent: Agent
  label: string
  detected: boolean
  readError: string | null
  processAlive: boolean | null
  running: number
  runningSubAgents: number
  lastActive: number
  files: number
  /** 见过的对话数（不含子代理） */
  conversations: number
  recentTools: { ts: number; name: string; server: string; ok: boolean }[]
  /** 这家的 token 是估算的（来源不记录 token） */
  estimated: boolean
  net: NetStats
}

export interface RatePoint {
  t: number
  input: number
  cacheRead: number
  cacheWrite: number
  output: number
  reasoning: number
  requests: number
}

export interface PhaseCounts {
  requesting: number
  thinking: number
  writing: number
  generating: number
  tool: number
  retrying: number
  waiting: number
}

export interface FinishedTurn {
  key: string
  agent: Agent
  title: string
  project: string
  endedAt: number
  durationMs: number
  totals: Totals
}

export interface RateWindow {
  usedPercent: number
  windowMinutes: number
  resetsAtMs: number
  /** 已用量和上限（按 unit 计）；limit 为 0 表示来源只给了百分比 */
  used: number
  limit: number
  /** 计量单位，比如 credits；空表示未知 */
  unit: string
  /** 额度名称；空时按 windowMinutes 命名 */
  label: string
  /** resetsAtMs 是到期时刻（赠送额度到期作废），不是重置时刻 */
  expires: boolean
}

export interface RateLimitView {
  agent: Agent
  ts: number
  plan: string
  primary: RateWindow | null
  secondary: RateWindow | null
}

export interface LiveStats {
  running: number
  runningSubAgents: number
  phases: PhaseCounts
  sessions: SessionView[]
  agents: AgentLive[]
  net: NetStats
  netEvents: NetEventView[]
  latency: LatencyPoint[]
  rate: RatePoint[]
  perSecond: RatePoint[]
  finished: FinishedTurn[]
  rateLimits: RateLimitView[]
}

export interface DayCell {
  t: number
  total: number
  requests: number
}

export interface ScanStats {
  journalError?: string | null
  files: number
  bytes: number
  events: number
  failing: number
  parsed: number
  scanMs: number
  firstScanMs: number
  scans: number
}

export interface Snapshot {
  generatedAt: number
  version: number
  utcOffsetMs: number
  ranges: RangeStats[]
  live: LiveStats
  heatmap: DayCell[]
  scan: ScanStats
}

// —— 单个 agent 的详情（get_agent_detail）——

export interface AgentPoint {
  t: number
  input: number
  cacheRead: number
  cacheWrite: number
  output: number
  reasoning: number
  requests: number
  credits: number
}

export interface AgentRange {
  id: RangeId
  from: number
  to: number
  totals: Totals
  previous: Totals | null
  /** 有用量的对话数（不含子代理） */
  sessions: number
  unit: 'hour' | 'day' | 'week'
  stepMs: number
  series: AgentPoint[]
  byModel: ModelTotals[]
  byProject: ProjectTotals[]
}

export interface ToolStat {
  name: string
  /** MCP 服务名；内置工具为空 */
  server: string
  calls: number
  errors: number
  last: number
}

export interface ServerStat {
  server: string
  calls: number
  tools: number
  errors: number
  last: number
}

export interface HourCell {
  /** 本地时间 0~23 点 */
  hour: number
  total: number
  requests: number
}

export interface AgentDetail {
  agent: Agent
  label: string
  /** token 是估算的 */
  estimated: boolean
  /** 估算口径的说明；不估算时为空 */
  estimateNote: string
  /** today / 7d / 30d / all */
  ranges: AgentRange[]
  /** 近 26 周每天 */
  heatmap: DayCell[]
  /** 近 30 天按小时分布 */
  hours: HourCell[]
  /** 调用次数最多的工具（全部时间） */
  tools: ToolStat[]
  /** 用到的 MCP 服务 */
  servers: ServerStat[]
  toolCalls: number
  toolErrors: number
  conversations: number
  subAgents: number
  /** 跑完的轮数 */
  turns: number
  firstSeen: number
  lastActive: number
}

export type UnitStyle = 'kmb' | 'wanyi'

export interface Settings {
  /** 显示灵动岛 */
  island: boolean
  edgeAutoHide: boolean
  /** 开机自启 */
  autostart: boolean
  /** 对话跑完一轮时在灵动岛上提示 */
  notifyFinished: boolean
  /** 数字单位：K/M/B 或 万/亿 */
  units: UnitStyle
  theme: 'dark' | 'light'
}

export interface AppInfo {
  version: string
  /** 各 agent 的数据目录，顺序同 AGENTS */
  roots: string[][]
  /** 设置文件保存的位置 */
  settingsPath: string
}
