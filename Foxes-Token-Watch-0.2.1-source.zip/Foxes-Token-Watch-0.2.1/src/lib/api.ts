import { invoke } from '@tauri-apps/api/core'
import { listen } from '@tauri-apps/api/event'
import { getCurrentWindow } from '@tauri-apps/api/window'
import { useEffect, useState, useSyncExternalStore } from 'react'
import { setUnitStyle } from './format'
import type { AppInfo, SessionView, Settings, Snapshot } from './types'

/** 在软件窗口里运行（而不是开发时用浏览器打开） */
export const inApp = typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window

export const DEFAULT_SETTINGS: Settings = {
  island: true,
  edgeAutoHide: true,
  autostart: false,
  notifyFinished: true,
  units: 'kmb',
  theme: 'dark',
}

type Listener = () => void

function createStore<T>(initial: T) {
  let value = initial
  const listeners = new Set<Listener>()
  return {
    get: () => value,
    set(next: T) {
      value = next
      listeners.forEach((listener) => listener())
    },
    subscribe(listener: Listener) {
      listeners.add(listener)
      return () => {
        listeners.delete(listener)
      }
    },
  }
}

const snapshotStore = createStore<Snapshot | null>(null)
const settingsStore = createStore<Settings>(DEFAULT_SETTINGS)

function applySettings(settings: Settings) {
  setUnitStyle(settings.units)
  document.documentElement.dataset.theme = settings.theme
  settingsStore.set(settings)
}

function publishSnapshot(snapshot: Snapshot) {
  const current = snapshotStore.get()
  if (!current || snapshot.generatedAt >= current.generatedAt) snapshotStore.set(snapshot)
}

let started = false

function start() {
  if (started) return
  started = true
  if (inApp) {
    void listen<Snapshot>('snapshot', (event) => publishSnapshot(event.payload))
    void listen<Settings>('settings', (event) => applySettings(event.payload))
    void invoke<Snapshot | null>('get_snapshot').then((snapshot) => snapshot && publishSnapshot(snapshot))
    void invoke<Settings>('get_settings').then(applySettings)
  } else {
    void import('./mock').then((mock) => mock.startMock(publishSnapshot))
    applySettings(DEFAULT_SETTINGS)
  }
}

function subscribeSnapshot(listener: Listener) {
  start()
  return snapshotStore.subscribe(listener)
}

function subscribeSettings(listener: Listener) {
  start()
  return settingsStore.subscribe(listener)
}

/** 最新的统计快照；第一次扫描完成前为 null */
export function useSnapshot(): Snapshot | null {
  return useSyncExternalStore(subscribeSnapshot, snapshotStore.get)
}

export function useSettings(): Settings {
  return useSyncExternalStore(subscribeSettings, settingsStore.get)
}

export async function updateSettings(patch: Partial<Settings>): Promise<void> {
  const next = { ...settingsStore.get(), ...patch }
  applySettings(next)
  if (inApp) applySettings(await invoke<Settings>('set_settings', { patch }))
}

/** 每隔一段时间重新渲染一次，给计时器用 */
export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), intervalMs)
    return () => window.clearInterval(timer)
  }, [intervalMs])
  return now
}

export async function fetchSessions(): Promise<SessionView[]> {
  if (inApp) return invoke<SessionView[]>('get_sessions')
  const mock = await import('./mock')
  return mock.mockSessions()
}

export async function fetchAppInfo(): Promise<AppInfo> {
  if (inApp) return invoke<AppInfo>('get_app_info')
  return { version: '0.2.1', roots: [['~/.claude'], ['~/.codex'], ['%LOCALAPPDATA%/Deepseek Harness EAC'], ['~/.gemini/antigravity']], settingsPath: 'Foxes-watch-data/settings.json' }
}

export type WindowAction = 'minimize' | 'toggleMaximize' | 'hide'

export function windowAction(action: WindowAction) {
  if (!inApp) return
  const current = getCurrentWindow()
  if (action === 'minimize') void current.minimize()
  else if (action === 'toggleMaximize') void current.toggleMaximize()
  else void current.hide()
}

export function startDragging() {
  if (inApp) void invoke('drag_island')
}

export type DockSide = 'left' | 'right' | null
const dockStore = createStore<DockSide>(null)
let dockStarted = false

function subscribeDock(listener: Listener) {
  if (!dockStarted && inApp) {
    dockStarted = true
    let received = false
    void listen<DockSide>('island-dock', (event) => {
      received = true
      dockStore.set(event.payload)
    }).then(async () => {
      const initial = await invoke<DockSide>('get_island_dock')
      if (!received) dockStore.set(initial)
    })
  }
  return dockStore.subscribe(listener)
}

export function useIslandDock() {
  return useSyncExternalStore(subscribeDock, dockStore.get)
}

export function setIslandDock(side: DockSide) {
  if (inApp) void invoke('set_island_dock', { side })
  else dockStore.set(side)
}

/** 打开（或唤起）主面板 */
export function openPanel() {
  if (inApp) void invoke('show_panel')
}

/**
 * 设置灵动岛窗口里“看得见、点得到”的范围（逻辑像素，贴着窗口顶边、左右居中）。
 * 范围之外的部分既不显示也不拦鼠标，点击会直接落到后面的窗口上。
 */
export function islandRegion(width: number, height: number, expanded: boolean): Promise<void> {
  return inApp ? invoke<void>('island_region', { width, height, expanded }).catch(() => undefined) : Promise.resolve()
}

/** 后台确认鼠标已经离开灵动岛时回调；返回取消监听的函数 */
export function onIslandLeave(handler: () => void): () => void {
  if (!inApp) return () => undefined
  const pending = listen('island-leave', handler)
  return () => void pending.then((unlisten) => unlisten())
}

export function quitApp() {
  if (inApp) void invoke('quit_app')
}
