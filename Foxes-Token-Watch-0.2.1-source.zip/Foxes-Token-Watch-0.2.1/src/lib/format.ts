import type { Agent, NetStatus, Phase, Totals, UnitStyle } from './types'

let unitStyle: UnitStyle = 'kmb'

export function setUnitStyle(style: UnitStyle) {
  unitStyle = style
}

/** 保留三位有效数字：1.67 / 29.2 / 123 */
function threeDigits(value: number): string {
  if (value >= 100) return Math.round(value).toString()
  if (value >= 10) return value.toFixed(1)
  return value.toFixed(2)
}

export interface Compact {
  value: string
  unit: string
}

export function compactParts(n: number, style: UnitStyle = unitStyle): Compact {
  const abs = Math.abs(n)
  if (style === 'wanyi') {
    if (abs >= 1e8) return { value: threeDigits(n / 1e8), unit: '亿' }
    if (abs >= 1e4) return { value: abs >= 1e7 ? Math.round(n / 1e4).toLocaleString('en-US') : threeDigits(n / 1e4), unit: '万' }
    return { value: Math.round(n).toLocaleString('en-US'), unit: '' }
  }
  if (abs >= 1e9) return { value: threeDigits(n / 1e9), unit: 'B' }
  if (abs >= 1e6) return { value: threeDigits(n / 1e6), unit: 'M' }
  if (abs >= 1e4) return { value: threeDigits(n / 1e3), unit: 'K' }
  return { value: Math.round(n).toLocaleString('en-US'), unit: '' }
}

/** 29.2M / 2915 万 */
export function fmtTokens(n: number, style: UnitStyle = unitStyle): string {
  const { value, unit } = compactParts(n, style)
  return unit ? (style === 'wanyi' ? `${value} ${unit}` : `${value}${unit}`) : value
}

/** 1,672,878,520 */
export function fmtFull(n: number): string {
  return Math.round(n).toLocaleString('en-US')
}

export function fmtPercent(ratio: number, digits = 1): string {
  if (!Number.isFinite(ratio)) return '—'
  return `${(ratio * 100).toFixed(digits)}%`
}

/** 缓存命中率：命中 / 全部输入侧 token */
export function hitRate(totals: Totals): number {
  const prompt = totals.input + totals.cacheRead + totals.cacheWrite
  return prompt > 0 ? totals.cacheRead / prompt : 0
}

/** 相对上一时段的变化，没有可比基数时返回 null */
export function delta(current: number, previous: number | undefined | null): number | null {
  if (previous === undefined || previous === null || previous <= 0) return null
  return (current - previous) / previous
}

export function fmtDelta(ratio: number): string {
  const percent = Math.abs(ratio) * 100
  const text = percent >= 1000 ? `${(percent / 100).toFixed(1)} 倍` : `${percent >= 100 ? Math.round(percent) : percent.toFixed(1)}%`
  return `${ratio >= 0 ? '↑' : '↓'} ${text}`
}

/** 0:47 / 12:05 / 1:02:33 */
export function fmtClock(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000))
  const hours = Math.floor(total / 3600)
  const minutes = Math.floor((total % 3600) / 60)
  const seconds = total % 60
  const pad = (value: number) => value.toString().padStart(2, '0')
  return hours > 0 ? `${hours}:${pad(minutes)}:${pad(seconds)}` : `${minutes}:${pad(seconds)}`
}

/** 45 秒 / 2 分 13 秒 / 1 小时 5 分 */
export function fmtDuration(ms: number): string {
  const total = Math.max(0, Math.round(ms / 1000))
  if (total < 60) return `${total} 秒`
  const minutes = Math.floor(total / 60)
  if (minutes < 60) return total % 60 ? `${minutes} 分 ${total % 60} 秒` : `${minutes} 分`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return minutes % 60 ? `${hours} 小时 ${minutes % 60} 分` : `${hours} 小时`
  const days = Math.floor(hours / 24)
  return hours % 24 ? `${days} 天 ${hours % 24} 小时` : `${days} 天`
}

/** 850 ms / 12.3 秒 / 2 分 5 秒 */
export function fmtMs(ms: number): string {
  if (ms <= 0) return '—'
  if (ms < 1000) return `${Math.round(ms)} ms`
  if (ms < 60_000) return `${(ms / 1000).toFixed(ms < 10_000 ? 2 : 1)} 秒`
  return fmtDuration(ms)
}

const pad2 = (value: number) => value.toString().padStart(2, '0')

export function fmtTime(ts: number, withSeconds = false): string {
  const date = new Date(ts)
  const base = `${pad2(date.getHours())}:${pad2(date.getMinutes())}`
  return withSeconds ? `${base}:${pad2(date.getSeconds())}` : base
}

export function fmtDate(ts: number): string {
  const date = new Date(ts)
  return `${date.getMonth() + 1}月${date.getDate()}日`
}

export function fmtDateTime(ts: number): string {
  const date = new Date(ts)
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())} ${fmtTime(ts)}`
}

export function fmtAgo(ts: number, now: number): string {
  if (ts <= 0) return '—'
  const diff = now - ts
  if (diff < 60_000) return '刚刚'
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)} 分钟前`
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)} 小时前`
  if (diff < 7 * 86_400_000) return `${Math.floor(diff / 86_400_000)} 天前`
  return fmtDate(ts)
}

export function fmtBytes(bytes: number): string {
  if (bytes >= 1 << 30) return `${(bytes / (1 << 30)).toFixed(2)} GB`
  if (bytes >= 1 << 20) return `${(bytes / (1 << 20)).toFixed(1)} MB`
  if (bytes >= 1 << 10) return `${(bytes / (1 << 10)).toFixed(0)} KB`
  return `${bytes} B`
}

export const AGENT_META: Record<Agent, { label: string; short: string; color: string }> = {
  claude: { label: 'Claude Code', short: 'Claude', color: 'var(--agent-claude)' },
  codex: { label: 'Codex', short: 'Codex', color: 'var(--agent-codex)' },
  deepseek: { label: 'Deepseek Harness', short: 'Deepseek', color: 'var(--agent-deepseek)' },
  kiro: { label: 'Kiro', short: 'Kiro', color: '#ae8bf5' },
  cursor: { label: 'Cursor', short: 'Cursor', color: '#7f9ab8' },
  webmcp: { label: '网页 MCP', short: '网页 MCP', color: '#2eb6a5' },
  antigravity: { label: '反重力 Antigravity', short: '反重力', color: 'var(--agent-antigravity)' },
}

export const PHASE_META: Record<Phase, { label: string; tone: string }> = {
  idle: { label: '空闲', tone: 'idle' },
  requesting: { label: '等待响应', tone: 'request' },
  thinking: { label: '思考中', tone: 'think' },
  writing: { label: '写入中', tone: 'write' },
  generating: { label: '生成中', tone: 'write' },
  tool: { label: '执行工具', tone: 'tool' },
  retrying: { label: '重试中', tone: 'retry' },
  waiting: { label: '等待确认', tone: 'wait' },
}

export const NET_META: Record<NetStatus, { label: string; tone: string; hint: string }> = {
  idle: { label: '暂无请求', tone: 'idle', hint: '最近 15 分钟没有请求，无从判断' },
  ok: { label: '通畅', tone: 'ok', hint: '最近的请求都正常返回' },
  slow: { label: '响应慢', tone: 'slow', hint: '首字延迟明显偏高' },
  unstable: { label: '不稳定', tone: 'unstable', hint: '最近有重试或报错，但还能连上' },
  down: { label: '连接失败', tone: 'down', hint: '连续失败，之后没有成功的响应' },
}

/** 对话在列表里显示的名字：标题优先，其次项目名 */
export function sessionName(session: { title: string; project: string; id: string }): string {
  return session.title || session.project || `对话 ${session.id.slice(-6)}`
}
