# Upstream license texts

These files supplement crates whose published packages omit the repository-level license text.

- `alloc-stdlib-0.3.0-LICENSE.txt`: [Dropbox's license at the source revision recorded in the crate](https://github.com/dropbox/rust-alloc-no-stdlib/blob/0a81fd6928ea3b33c8cd484aa4575d50ffb98012/LICENSE).
- `webview2-rs-LICENSE.txt`: [webview2-rs's license at the source revision recorded in the crates](https://github.com/wravery/webview2-rs/blob/edc2caf886175ccaebe86078c9cfe1ae2a187328/LICENSE).
- `MPL-2.0.txt`: [Mozilla Public License 2.0](https://www.mozilla.org/MPL/2.0/). The unmodified `selectors` crate source is available at [version 0.38.0](https://crates.io/crates/selectors/0.38.0) and the [upstream revision](https://github.com/servo/stylo/tree/572ecba2d1600e7c3d490586692a209faf703baa/selectors).
